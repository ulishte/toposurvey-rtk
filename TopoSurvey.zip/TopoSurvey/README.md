# TopoSurvey (Faza 1)

Aplikacion Android (Kotlin + Jetpack Compose) për rilevime topografike me GNSS
rover të lidhur me Bluetooth, i frymëzuar nga funksionalitetet e Dimap por i
ndërtuar nga e para me kod origjinal dhe protokolle standarde e hapura
(NMEA-0183 + NTRIP), jo me SDK-të pronësore që përdor Dimap (Qianxun/Sixents/
Cmcc/LuoWang, MxDraw CAD, etj. - ato janë licencuar për Bingce/Dimap dhe nuk
mund të rikrijohen ligjërisht pa marrëveshje me ta).

## Çfarë u gjet duke analizuar Dimap.apk

Dimap është një aplikacion profesional rilevimi RTK me module shumë të gjera:
lidhje instrumenti (Bluetooth SPP/BLE/OTG serial/radio/statik), korrigjime RTK
nga rrjete CORS pronësore, rilevim & skedarizim pikash, skedarizim vijash/CAD,
projektim rrugësh (planimetri, profil gjatësor, mbivendosje, gjerësim),
transformime koordinatash (4/7 parametra, projeksione, elipsoidë), llogaritje
gjeometrike & dherash, korrigjim tilt-i (IMU), dhe menaxhim projektesh/eksport.
Kjo është një produkt komercial disa-vjeçar i ndërtuar nga një ekip - nuk
riprodhohet 1:1 në një hap.

## Çfarë përfshin kjo Fazë 1

- Lidhje Bluetooth (SPP) me rover-in, leximi i vazhdueshëm i NMEA (GGA).
- Parser NMEA (GGA) → gjerësi/gjatësi/lartësi elipsoidale, cilësia e fiksit
  (invalid/GPS/DGPS/RTK float/RTK fixed), HDOP, nr. satelitësh.
- Klient NTRIP standard (v1/v2) → merr korrigjime RTCM nga çdo caster CORS dhe
  i dërgon te rover-i nëpër të njëjtin socket Bluetooth.
- Projekte + pika në bazë të dhënash lokale (Room).
- Ekran Rilevimi: pozicioni live, regjistrim pike me kod/përshkrim.
- Libraria e Pikave: listë, fshirje, eksport CSV.
- Skedarizim bazë: distanca & azimuti live drejt një pike të zgjedhur.

## Çfarë NUK është ende (roadmap Fazë 2+)

- Sisteme koordinatash lokale/projeksione, transformime 4/7 parametra
  (aktualisht vetëm WGS84 lat/lon/lartësi elipsoidale).
- Skedarizim linje/CAD, import DXF/shp, harta.
- Projektim rrugësh, seksione tërthore, mbivendosje.
- Korrigjim tilt-i (IMU) për shtyllën e rilevimit.
- Llogaritje sipërfaqesh/dherash, interseksione gjeometrike.
- Eksport formatesh të personalizuara, KML/SHP.
- BLE dhe OTG serial (tani vetëm Bluetooth klasik SPP).

Këto mund të shtohen në module të veçanta pa prekur themelin (të dhënat,
lidhjen me rover-in, NTRIP) - struktura është menduar pikërisht për këtë.

## Si të hapësh projektin

1. Instalo **Android Studio** (Koala/2024.1 ose më e re).
2. `File > Open` → zgjidh dosjen `TopoSurvey/`.
3. Lëre Gradle të sinkronizojë (do të shkarkojë varësitë - Compose, Room, etj.).
4. Lidh një telefon Android (minSdk 26 / Android 8+) me USB debugging, ose
   përdor një emulator me Bluetooth (kufizuar - Bluetooth reale kërkon pajisje
   fizike për testim me rover-in).
5. Run.

## Testim pa rover fizik

Për të testuar parsimin NMEA dhe UI pa pasur rover në dorë, mund të përdorësh
një app tjetër/skript në telefonin çift Bluetooth që dërgon linja GGA fiktive
nëpër SPP, ose të shtosh (Fazë 2) një "burim i simuluar" në `SurveyEngine` që
lexon një skedar `.nmea` në vend të socket-it Bluetooth.

## Struktura e kodit

```
app/src/main/java/com/toposurvey/app/
  data/        Room: SurveyProjectEntity, SurveyPointEntity, DAO, Repository
  gnss/        NmeaParser, GnssFix, NtripClient
  bluetooth/   BluetoothLinkManager (SPP)
  util/        GeoMath (distancë/azimut)
  export/      CsvExporter
  ui/          Compose: home, device, survey, library, stakeout, ntrip, theme, nav
  SurveyEngine.kt   Lidh Bluetooth ↔ NMEA parser ↔ NTRIP (singleton i aplikacionit)
  TopoSurveyApp.kt  Application, inicializon DB + SurveyEngine
  MainActivity.kt
```
