# TopoSurvey (Faza 2)

Aplikacion Android (Kotlin + Jetpack Compose) për rilevime topografike me GNSS
rover të lidhur me Bluetooth, i frymëzuar nga funksionalitetet e Dimap por i
ndërtuar nga e para me kod origjinal dhe protokolle standarde e hapura
(NMEA-0183 + NTRIP), jo me SDK-të pronësore që përdor Dimap (Qianxun/Sixents/
Cmcc/LuoWang, MxDraw CAD, etj. - ato janë licencuar për Bingce/Dimap dhe nuk
mund të rikrijohen ligjërisht pa marrëveshje me ta).

## Çfarë u gjet duke analizuar Dimap.apk

Dimap është një aplikacion profesional rilevimi RTK me module shumë të gjera:
lidhje instrumenti (Bluetooth SPP/BLE/OTG serial/radio/statik), korrigjime RTK
nga rrjete CORS pronësore, rilevim & skedarizim pikash, skedarizim vijash/CAD,
projektim rrugësh (planimetri, profil gjatësor, mbivendosje, gjerësim),
transformime koordinatash (4/7 parametra, projeksione, elipsoidë), llogaritje
gjeometrike & dherash, korrigjim tilt-i (IMU), dhe menaxhim projektesh/eksport.
Kjo është një produkt komercial disa-vjeçar i ndërtuar nga një ekip - nuk
riprodhohet 1:1 në një hap.

## Çfarë përfshin

- Lidhje Bluetooth (SPP) me rover-in, leximi i vazhdueshëm i NMEA (GGA).
- Parser NMEA (GGA) → gjerësi/gjatësi/lartësi elipsoidale, cilësia e fiksit
  (invalid/GPS/DGPS/RTK float/RTK fixed), HDOP, nr. satelitësh.
- Klient NTRIP standard (v1/v2) → merr korrigjime RTCM nga çdo caster CORS dhe
  i dërgon te rover-i nëpër të njëjtin socket Bluetooth.
- **Sisteme koordinatash dhe projeksione (Faza 2):**
  - Elipsoidë: WGS84, GRS80, International 1924, Krassovsky, Bessel, Clarke 1866.
  - Projeksion Transverse Mercator (formulat Snyder/USGS), me konvergjencë rrjeti
    dhe faktor shkalle pikësor.
  - Transformim datumi Helmert me 7 parametra (Bursa-Wolf) nëpërmjet ECEF.
  - Lokalizim vendor me 4 parametra (shkallë, rrotullim, 2 zhvendosje) me katrorë
    më të vegjël + zhvendosje vertikale, me residuale për kontroll cilësie.
  - Presets: **KRGJSH-2010 (Shqipëri)**, UTM 34N, UTM 33N, WGS84 gjeografike.
- Projekte + pika në bazë të dhënash lokale (Room). Çdo projekt mban sistemin e vet.
- Ekran Rilevimi: pozicioni live në **N/E/H** të sistemit të projektit + WGS84 i papërpunuar.
- Libraria e Pikave: listë me N/E/H, fshirje, eksport CSV (rrjet + WGS84).
- Skedarizim në koordinata rrjeti: objektiv manual (N/E/H) ose nga libraria,
  me delta veri/lindje, distancë, azimut rrjeti dhe cut/fill.

### Saktësia e matematikës

Formulat e projeksionit janë verifikuar kundrejt shembullit të publikuar të
Snyder-it ("Map Projections - A Working Manual"): Clarke 1866, k0=0.9996,
CM 75°W, pika 40°30'N 73°30'W → x=127106.5 m, y=4484124.4 m — përputhje ekzakte.
Round-trip përpara/prapa mbetet nën 0.1 mm brenda një zone kombëtare, shumë nën
zhurmën e vetë GNSS-së.

## Çfarë NUK është ende (roadmap)

- Ekran për të futur pika kontrolli dhe për të llogaritur lokalizimin nga terreni
  (matematika e 4 parametrave është gati, i mungon vetëm UI-ja).
- Model gjeoidi (aktualisht lartësi elipsoidale + zhvendosje konstante).
- Skedarizim linje/CAD, import DXF/shp, harta.
- Projektim rrugësh, seksione tërthore, mbivendosje.
- Korrigjim tilt-i (IMU) për shtyllën e rilevimit.
- Llogaritje sipërfaqesh/dherash, interseksione gjeometrike.
- Eksport KML/SHP/DXF.
- BLE dhe OTG serial (tani vetëm Bluetooth klasik SPP).

## Si të hapësh projektin

1. Instalo **Android Studio** (Koala/2024.1 ose më e re).
2. `File > Open` → zgjidh dosjen `TopoSurvey/`.
3. Lëre Gradle të sinkronizojë (do të shkarkojë varësitë - Compose, Room, etj.).
4. Lidh një telefon Android (minSdk 26 / Android 8+) me USB debugging, ose
   përdor një emulator me Bluetooth (kufizuar - Bluetooth reale kërkon pajisje
   fizike për testim me rover-in).
5. Run.

## Testim pa rover fizik

Për të testuar parsimin NMEA dhe UI pa pasur rover në dorë, mund të përdorësh
një app tjetër/skript në telefonin çift Bluetooth që dërgon linja GGA fiktive
nëpër SPP, ose të shtosh (Fazë 2) një "burim i simuluar" në `SurveyEngine` që
lexon një skedar `.nmea` në vend të socket-it Bluetooth.

## Struktura e kodit

```
app/src/main/java/com/toposurvey/app/
  data/        Room: SurveyProjectEntity, SurveyPointEntity, DAO, Repository
  geo/         Ellipsoid, TransverseMercator, Datum (ECEF+Helmert),
               CoordinateSystem (+presets), Localization (4 parametra)
  gnss/        NmeaParser, GnssFix, NtripClient
  bluetooth/   BluetoothLinkManager (SPP)
  util/        GeoMath (distancë/azimut)
  export/      CsvExporter
  ui/          Compose: home, device, survey, library, stakeout, ntrip,
               coordsys, theme, nav
  SurveyEngine.kt   Lidh Bluetooth ↔ NMEA parser ↔ NTRIP (singleton i aplikacionit)
  TopoSurveyApp.kt  Application, inicializon DB + SurveyEngine
  MainActivity.kt
```
