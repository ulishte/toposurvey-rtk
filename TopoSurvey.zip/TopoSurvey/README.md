# TopoSurvey

Aplikacion Android (Kotlin + Jetpack Compose) për rilevime topografike me GNSS
rover të lidhur me Bluetooth, i frymëzuar nga funksionalitetet e Dimap por i
ndërtuar nga e para me kod origjinal dhe protokolle standarde e hapura
(NMEA-0183 + NTRIP), jo me SDK-të pronësore që përdor Dimap (Qianxun/Sixents/
Cmcc/LuoWang, MxDraw CAD, etj. - ato janë licencuar për Bingce/Dimap dhe nuk
mund të rikrijohen ligjërisht pa marrëveshje me ta).

## Çfarë u gjet duke analizuar Dimap.apk

Dimap është një aplikacion profesional rilevimi RTK me module shumë të gjera:
lidhje instrumenti (Bluetooth SPP/BLE/OTG serial/radio/statik), korrigjime RTK
nga rrjete CORS pronësore, rilevim & skedarizim pikash, skedarizim vijash/CAD,
projektim rrugësh (planimetri, profil gjatësor, mbivendosje, gjerësim),
transformime koordinatash (4/7 parametra, projeksione, elipsoidë), llogaritje
gjeometrike & dherash, korrigjim tilt-i (IMU), dhe menaxhim projektesh/eksport.
Kjo është një produkt komercial disa-vjeçar i ndërtuar nga një ekip - nuk
riprodhohet 1:1 në një hap.

## Çfarë përfshin

### Lidhja me instrumentin
- **Bluetooth klasik (SPP)** dhe **BLE** (serial mbi GATT — Nordic UART dhe
  HM-10), për rover-at e vjetër dhe të rinj njësoj.
- Parser NMEA (GGA): pozicion, lartësi elipsoidale, cilësi fiksi, HDOP, satelitë.
- Klient NTRIP standard (v1/v2) → korrigjime RTCM nga çdo caster CORS, të
  dërguara te rover-i nëpër të njëjtin socket Bluetooth.

### Rilevimi
- **Lartësia e shkopit** zbritet automatikisht — çdo H e ruajtur është e markës
  në tokë, jo e antenës. (Burimi klasik i një gabimi konstant në gjithë punën.)
- **Mesatarizim epokash**: mat N epoka, ruaj mesataren, me RMS horizontal e
  vertikal si tregues cilësie.
- Paralajmërim kur zgjidhja nuk është RTK Fixed.
- Kod pike që rritet vetvetiu (P12 → P13).
- **Lartësi ortometrike (mbi nivelin e detit)** krahas asaj elipsoidale, duke
  ruajtur ndarjen e gjeoidit që raporton marrësi.
- Redaktim i kodit dhe përshkrimit të pikave pas matjes.

### Koordinatat
- Elipsoidë: WGS84, GRS80, International 1924, Krassovsky, Bessel, Clarke 1866.
- Transverse Mercator (Snyder/USGS) me konvergjencë rrjeti dhe faktor shkalle.
- Helmert 7-parametra (Bursa-Wolf) nëpërmjet ECEF.
- Presets: **KRGJSH-2010 (Shqipëri)**, UTM 34N, UTM 33N, WGS84 gjeografike.
- **Kalibrim vendor**: pika kontrolli me koordinata të njohura → përshtatje me 4
  parametra (shkallë, rrotullim, 2 zhvendosje) + zhvendosje vertikale, me
  residuale për pikë, maksimum dhe RMS. Ruhet për projektin.

### Puna në terren
- **Pamja e Punës**: hartë vektoriale e projektit me pikat, pozicionin live dhe
  shkallë metrike. Pa internet, pa çelësa API — vizatohen koordinatat e vetë
  projektit, prandaj funksionon edhe pa sinjal.
- Skedarizim pikash me koordinata projekti: objektiv manual N/E/H, nga libraria,
  ose nga një CSV projekti. Jep ΔN/ΔE, distancë, azimut rrjeti dhe cut/fill.
- **Skedarizim linje**: përcakto boshtin nga dy pika ose me koordinata, dhe merr
  live stacionin (kilometrazhin), ofsetin me anën (djathtas/majtas) dhe cut/fill
  kundrejt lartësisë së projektit të interpoluar.
- Llogaritje sipërfaqeje me formulën e Gauss-it: **m², dynym dhe hektarë**, plus
  perimetër.
- COGO: inverse (distancë + azimut mes dy pikave, edhe në gradë-minuta-sekonda)
  dhe radiacion (pikë e re nga azimut + distancë).

### Të dhënat
- Projekte dhe pika në bazë të dhënash lokale (Room); çdo projekt mban sistemin
  dhe kalibrimin e vet.
- Eksport **CSV** (rrjet + WGS84), **DXF** (R12 — hapet në AutoCAD/Civil 3D/QGIS)
  dhe **KML** (Google Earth), me dërgim direkt nga aplikacioni.
- Import CSV i pikave të projektit për skedarizim.

## Saktësia e matematikës

Formulat nuk janë marrë "me mend" — janë verifikuar kundrejt vlerave referencë:

- **Projeksioni**: shembulli i publikuar i Snyder-it ("Map Projections — A
  Working Manual"): Clarke 1866, k0=0.9996, CM 75°W, pika 40°30′N 73°30′W →
  x=127106.5 m, y=4484124.4 m. Përputhje ekzakte. Round-trip nën 0.1 mm.
- **ECEF ↔ gjeodezike**: round-trip me gabim ~1e-15°, dhe kontroll kundrejt
  vlerave të njohura (X=a në ekuator, Z=b në pol).
- **Kalibrimi 4-parametrash**: nga një transformim i sintetizuar (shkallë
  1.000012, rrotullim 0.35°) parametrat rikthehen saktësisht, residual 0.
- **Sipërfaqja**: katror 100×100 → 10000 m²; trekëndësh 300/400 → 60000 m²
  me perimetër 1200 m; figurë L → 7600 m². Rendi i kundërt jep të njëjtën
  sipërfaqe.
- **COGO**: radiacion → inverse kthen azimutin dhe distancën fillestare me
  gabim ~1e-11.
- **Stacion/ofset**: pikë 7 m në lindje të një boshti drejt veriut jep ofset
  +7.000 (djathtas); i njëjti bosht drejt lindjes me pikë 5 m në jug jep +5.000;
  pikë mbi bosht diagonal jep ofset 0 dhe stacion 70.711 për 50/50.

## Çfarë NUK është ende, dhe pse

Këto mbeten qëllimisht jashtë, sepse secila kërkon ose të dhëna/pajisje që nuk
mund të verifikohen këtu, ose punë në shkallë produkti komercial:

- **Model gjeoidi kombëtar** — tani përdoret ndarja e gjeoidit që jep vetë
  marrësi (zakonisht EGM96/EGM2008) plus zhvendosja vertikale nga kalibrimi.
  Një model zyrtar shqiptar do të kërkonte skedarin përkatës të rrjetit.
- **Korrigjim tilt-i (IMU)** — të dhënat e prirjes vijnë me fraza NMEA
  pronësore, të ndryshme për çdo prodhues; pa dokumentacionin e rover-it tënd
  do të ishte hamendësim.
- **Llogaritje volumesh (dherash)** — kërkon model TIN të sipërfaqes; një
  përafrim "lartësi mesatare × sipërfaqe" do të jepte numra që duken të saktë
  por nuk janë, prandaj u la jashtë.
- **Projektim rrugësh** (spirale, mbivendosje, gjerësim, profil gjatësor) dhe
  **CAD interaktiv me import DXF** — module të tëra më vete.
- **Harta satelitore në sfond** — kërkon çelës API dhe internet në terren.

## Si të hapësh projektin

1. Instalo **Android Studio** (Koala/2024.1 ose më e re).
2. `File > Open` → zgjidh dosjen `TopoSurvey/`.
3. Lëre Gradle të sinkronizojë (do të shkarkojë varësitë - Compose, Room, etj.).
4. Lidh një telefon Android (minSdk 26 / Android 8+) me USB debugging, ose
   përdor një emulator me Bluetooth (kufizuar - Bluetooth reale kërkon pajisje
   fizike për testim me rover-in).
5. Run.

## Testim pa rover fizik

Për të testuar parsimin NMEA dhe UI pa pasur rover në dorë, mund të përdorësh
një app tjetër/skript në telefonin çift Bluetooth që dërgon linja GGA fiktive
nëpër SPP, ose të shtosh (Fazë 2) një "burim i simuluar" në `SurveyEngine` që
lexon një skedar `.nmea` në vend të socket-it Bluetooth.

## Struktura e kodit

```
app/src/main/java/com/toposurvey/app/
  data/        Room: SurveyProjectEntity, SurveyPointEntity, DAO, Repository
  geo/         Ellipsoid, TransverseMercator, Datum (ECEF+Helmert),
               CoordinateSystem (+presets), Localization (4 parametra), Cogo
  gnss/        NmeaParser, GnssFix, NtripClient
  bluetooth/   BluetoothLinkManager (SPP), BleLinkManager (GATT)
  util/        GeoMath (distancë/azimut)
  export/      CsvExporter, DxfExporter, KmlExporter, PointCsvImporter, ExportSharing
  survey/      EpochAverager (mesatarizim + RMS)
  ui/          Compose: home, device, survey, library, stakeout, linestake,
               plan, ntrip, coordsys, calibration, calc, theme, nav
  SurveyEngine.kt   Lidh Bluetooth ↔ NMEA parser ↔ NTRIP (singleton i aplikacionit)
  TopoSurveyApp.kt  Application, inicializon DB + SurveyEngine
  MainActivity.kt
```
