package com.toposurvey.app.ui.linestake

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.toposurvey.app.geo.Cogo
import kotlin.math.abs

/**
 * Stake to a straight alignment. Shows chainage (station), perpendicular
 * offset with the side, and cut/fill against the interpolated design height -
 * the standard way roads, kerbs, walls and pipelines get set out.
 */
@Composable
fun LineStakeScreen(navController: NavHostController, viewModel: LineStakeViewModel = viewModel()) {
    val line by viewModel.line.collectAsState()
    val current by viewModel.currentGrid.collectAsState()
    val points by viewModel.points.collectAsState()
    val picked by viewModel.picked.collectAsState()
    val message by viewModel.message.collectAsState()

    var sN by remember { mutableStateOf("") }
    var sE by remember { mutableStateOf("") }
    var sH by remember { mutableStateOf("") }
    var eN by remember { mutableStateOf("") }
    var eE by remember { mutableStateOf("") }
    var eH by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Skedarizim Linje", style = MaterialTheme.typography.headlineSmall)

        val l = line
        if (l != null && current != null) {
            val so = viewModel.stationOffset(current!!, l)
            if (so != null) {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Stacioni: ${"%.3f".format(so.station)} m", style = MaterialTheme.typography.headlineSmall)
                        Text(
                            "Ofseti: ${"%.3f".format(abs(so.offset))} m " +
                                if (so.isRight) "DJATHTAS" else "MAJTAS",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Text("Gjatësia e linjës: ${"%.3f".format(so.lineLength)} m")
                        Text("Azimuti i linjës: ${"%.3f".format(so.lineBearingDegrees)}°  (${Cogo.toDms(so.lineBearingDegrees)})")
                        if (so.beforeStart) Text("⚠ Para fillimit të linjës")
                        if (so.beyondEnd) Text("⚠ Përtej fundit të linjës")

                        val design = viewModel.designHeight(l, so)
                        if (design != null) {
                            val delta = design - current!!.height
                            Text(
                                (if (delta > 0) "Mbush (fill): " else "Gërmo (cut): ") +
                                    "${"%.3f".format(abs(delta))} m",
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text("H projekti: ${"%.3f".format(design)} m", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
            OutlinedButton(onClick = { viewModel.clearLine() }, modifier = Modifier.fillMaxWidth()) {
                Text("Ndrysho linjën")
            }
        } else {
            if (l != null) Text("Ende pa pozicion nga rover-i.")

            Text("Përcakto linjën me koordinata:", style = MaterialTheme.typography.titleSmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Num(sN, { sN = it }, "N fillimi", Modifier.weight(1f))
                Num(sE, { sE = it }, "E fillimi", Modifier.weight(1f))
                Num(sH, { sH = it }, "H", Modifier.weight(0.8f))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Num(eN, { eN = it }, "N fundi", Modifier.weight(1f))
                Num(eE, { eE = it }, "E fundi", Modifier.weight(1f))
                Num(eH, { eH = it }, "H", Modifier.weight(0.8f))
            }
            Button(
                onClick = { viewModel.setManualLine(sN, sE, eN, eE, sH, eH) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Vendos linjën") }

            Text(
                "Ose zgjidh 2 pika nga libraria (zgjedhur: ${picked.size}/2):",
                style = MaterialTheme.typography.titleSmall
            )
            points.forEach { p ->
                val index = picked.indexOfFirst { it.id == p.id }
                Card(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        Modifier.padding(12.dp).fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("${p.code} - ${p.description}")
                            if (index >= 0) {
                                Text(
                                    if (index == 0) "Fillimi" else "Fundi",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                        Button(onClick = { viewModel.pick(p) }) {
                            Text(if (index >= 0) "Hiq" else "Zgjidh")
                        }
                    }
                }
            }
        }

        message?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    }
}

@Composable
private fun Num(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier
    )
}
