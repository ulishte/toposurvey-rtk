package com.toposurvey.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ProjectDao {
    @Query("SELECT * FROM projects ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<SurveyProjectEntity>>

    @Insert
    suspend fun insert(project: SurveyProjectEntity): Long

    @Delete
    suspend fun delete(project: SurveyProjectEntity)

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getById(id: Long): SurveyProjectEntity?
}
