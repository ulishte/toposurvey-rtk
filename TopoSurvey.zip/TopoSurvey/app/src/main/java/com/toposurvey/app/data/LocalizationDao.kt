package com.toposurvey.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface LocalizationDao {
    @Query("SELECT * FROM localizations WHERE projectId = :projectId")
    suspend fun get(projectId: Long): LocalizationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: LocalizationEntity)

    @Query("DELETE FROM localizations WHERE projectId = :projectId")
    suspend fun clear(projectId: Long)
}
