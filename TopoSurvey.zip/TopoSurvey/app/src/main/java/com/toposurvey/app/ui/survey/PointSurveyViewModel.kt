package com.toposurvey.app.ui.survey

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.toposurvey.app.SurveyEngine
import com.toposurvey.app.TopoSurveyApp
import com.toposurvey.app.data.SurveyPointEntity
import com.toposurvey.app.geo.CoordinateSystem
import com.toposurvey.app.geo.GridResult
import com.toposurvey.app.gnss.GnssFix
import com.toposurvey.app.survey.AveragedPosition
import com.toposurvey.app.survey.EpochAverager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.take
import kotlinx.coroutines.flow.toList
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

sealed class CaptureState {
    data object Idle : CaptureState()
    data class Collecting(val collected: Int, val total: Int) : CaptureState()
    data class Saved(val summary: String) : CaptureState()
    data class Failed(val reason: String) : CaptureState()
}

class PointSurveyViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as TopoSurveyApp).repository

    val currentFix: StateFlow<GnssFix?> = SurveyEngine.currentFix
    val currentGrid: StateFlow<GridResult?> = SurveyEngine.currentGrid
    val coordinateSystem: StateFlow<CoordinateSystem> = SurveyEngine.coordinateSystem
    val antennaHeight: StateFlow<Double> = SurveyEngine.antennaHeight

    private val _capture = MutableStateFlow<CaptureState>(CaptureState.Idle)
    val capture: StateFlow<CaptureState> = _capture

    /** Next code, auto-incremented from the last stored point. */
    private val _suggestedCode = MutableStateFlow("1")
    val suggestedCode: StateFlow<String> = _suggestedCode

    init {
        refreshSuggestedCode()
    }

    fun setAntennaHeight(text: String) {
        text.replace(",", ".").toDoubleOrNull()?.let { SurveyEngine.setAntennaHeight(it) }
    }

    private fun refreshSuggestedCode() {
        val projectId = SurveyEngine.activeProjectId ?: return
        viewModelScope.launch {
            val points = repository.getPointsOnce(projectId)
            _suggestedCode.value = nextCode(points.map { it.code })
        }
    }

    /** "P12" -> "P13", "7" -> "8", anything else gets a numeric suffix. */
    private fun nextCode(existing: List<String>): String {
        val last = existing.firstOrNull() ?: return "1"
        val match = Regex("^(.*?)(\\d+)$").find(last) ?: return "$last-1"
        val prefix = match.groupValues[1]
        val digits = match.groupValues[2]
        val next = (digits.toLongOrNull() ?: 0L) + 1
        return prefix + next.toString().padStart(digits.length, '0')
    }

    /**
     * Collect [epochs] GNSS epochs, average them, subtract the antenna height
     * and store the ground mark.
     */
    fun collectPoint(code: String, description: String, epochs: Int) {
        val projectId = SurveyEngine.activeProjectId
        if (projectId == null) {
            _capture.value = CaptureState.Failed("Zgjidh një projekt te faqja kryesore.")
            return
        }
        if (SurveyEngine.currentFix.value == null) {
            _capture.value = CaptureState.Failed("Ende pa pozicion nga rover-i.")
            return
        }

        val wanted = epochs.coerceIn(1, 120)
        _capture.value = CaptureState.Collecting(0, wanted)

        viewModelScope.launch {
            // Epochs arrive ~1 Hz; allow generous headroom before giving up.
            val collected = withTimeoutOrNull(wanted * 2000L + 8000L) {
                SurveyEngine.fixes.take(wanted).toList()
            }

            if (collected.isNullOrEmpty()) {
                _capture.value = CaptureState.Failed("Nuk u morën epoka - kontrollo lidhjen.")
                return@launch
            }

            val avg: AveragedPosition = EpochAverager.average(collected)!!
            val groundHeight = avg.ellipsoidalHeight - SurveyEngine.antennaHeight.value

            repository.addPoint(
                SurveyPointEntity(
                    projectId = projectId,
                    code = code.ifBlank { _suggestedCode.value },
                    description = description,
                    latitude = avg.latitude,
                    longitude = avg.longitude,
                    ellipsoidalHeight = groundHeight,
                    antennaHeight = SurveyEngine.antennaHeight.value,
                    fixQuality = avg.worstFix.code,
                    hdop = avg.hdop,
                    satellites = avg.satellites,
                    epochsAveraged = avg.epochs,
                    timestampUtc = avg.timestampMillis
                )
            )

            val warning = if (EpochAverager.isSurveyGrade(avg.worstFix)) ""
            else "  ⚠ fiksi ${avg.worstFix} (jo RTK Fixed)"

            _capture.value = CaptureState.Saved(
                "Ruajtur: ${avg.epochs} epoka · RMS oriz. ${"%.3f".format(avg.horizontalRmsMetres)} m · " +
                    "vert. ${"%.3f".format(avg.verticalRmsMetres)} m$warning"
            )
            refreshSuggestedCode()
        }
    }

    fun resetCapture() {
        _capture.value = CaptureState.Idle
    }
}
