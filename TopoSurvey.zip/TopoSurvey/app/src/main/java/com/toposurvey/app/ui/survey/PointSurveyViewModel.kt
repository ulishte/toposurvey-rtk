package com.toposurvey.app.ui.survey

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.toposurvey.app.SurveyEngine
import com.toposurvey.app.TopoSurveyApp
import com.toposurvey.app.data.SurveyPointEntity
import com.toposurvey.app.gnss.GnssFix
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class PointSurveyViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as TopoSurveyApp).repository

    val currentFix: StateFlow<GnssFix?> = SurveyEngine.currentFix

    /** Null means no project has been selected yet on the Home screen. */
    val activeProjectId: Long? get() = SurveyEngine.activeProjectId

    fun collectPoint(code: String, description: String, onDone: (Boolean) -> Unit) {
        val projectId = activeProjectId
        val fix = currentFix.value
        if (projectId == null || fix == null) {
            onDone(false)
            return
        }
        viewModelScope.launch {
            repository.addPoint(
                SurveyPointEntity(
                    projectId = projectId,
                    code = code.ifBlank { "PT" },
                    description = description,
                    latitude = fix.latitude,
                    longitude = fix.longitude,
                    ellipsoidalHeight = fix.ellipsoidalHeight,
                    fixQuality = fix.fixQuality.code,
                    hdop = fix.hdop,
                    satellites = fix.satellites,
                    timestampUtc = fix.timestampMillis
                )
            )
            onDone(true)
        }
    }
}
