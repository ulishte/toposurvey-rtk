package com.toposurvey.app.ui.calibration

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.toposurvey.app.SurveyEngine
import com.toposurvey.app.TopoSurveyApp
import com.toposurvey.app.data.ControlPointEntity
import com.toposurvey.app.data.LocalizationEntity
import com.toposurvey.app.geo.ControlPointPair
import com.toposurvey.app.geo.GridXY
import com.toposurvey.app.geo.Localization
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Fit summary shown to the surveyor before they accept a calibration. */
data class FitReport(
    val scale: Double,
    val rotationDegrees: Double,
    val verticalShift: Double,
    val residuals: List<Pair<String, Double>>,
    val maxResidual: Double,
    val rmsResidual: Double,
    val usedPoints: Int
)

class CalibrationViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as TopoSurveyApp).repository
    private val projectId = SurveyEngine.activeProjectId

    val controlPoints: StateFlow<List<ControlPointEntity>> =
        (if (projectId != null) repository.observeControlPoints(projectId) else flowOf(emptyList()))
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _report = MutableStateFlow<FitReport?>(null)
    val report: StateFlow<FitReport?> = _report

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    private val _applied = MutableStateFlow(!SurveyEngine.localization.isIdentity)
    val applied: StateFlow<Boolean> = _applied

    init {
        // Restore any calibration already saved for this project.
        val id = projectId
        if (id != null) {
            viewModelScope.launch {
                repository.getLocalization(id)?.let {
                    SurveyEngine.setLocalization(Localization(it.a, it.b, it.tx, it.ty, it.verticalShift))
                    _applied.value = true
                }
                recompute()
            }
        }
    }

    /**
     * Capture the current rover position as the "measured" side of a pair.
     * The measurement must be taken WITHOUT the calibration applied, otherwise
     * the fit would be computed against its own output.
     */
    fun addFromCurrentPosition(label: String, knownN: String, knownE: String, knownH: String) {
        val id = projectId ?: run {
            _message.value = "Zgjidh një projekt së pari."
            return
        }
        val fix = SurveyEngine.currentFix.value ?: run {
            _message.value = "Ende pa pozicion nga rover-i."
            return
        }
        val n = knownN.replace(",", ".").toDoubleOrNull()
        val e = knownE.replace(",", ".").toDoubleOrNull()
        if (n == null || e == null) {
            _message.value = "Shkruaj koordinatat e njohura N dhe E."
            return
        }
        val h = knownH.replace(",", ".").toDoubleOrNull()

        val groundHeight = SurveyEngine.groundHeight(fix)
        val measured = SurveyEngine.projectUncalibrated(fix.latitude, fix.longitude, groundHeight) ?: run {
            _message.value = "Sistemi aktual s'ka projeksion - zgjidh p.sh. KRGJSH-2010."
            return
        }

        viewModelScope.launch {
            repository.addControlPoint(
                ControlPointEntity(
                    projectId = id,
                    label = label.ifBlank { "KP${controlPoints.value.size + 1}" },
                    measuredEasting = measured.easting,
                    measuredNorthing = measured.northing,
                    measuredHeight = measured.height,
                    knownEasting = e,
                    knownNorthing = n,
                    knownHeight = h ?: measured.height
                )
            )
            _message.value = "Pika e kontrollit u shtua."
            recompute()
        }
    }

    fun delete(point: ControlPointEntity) {
        viewModelScope.launch {
            repository.deleteControlPoint(point)
            recompute()
        }
    }

    fun toggleEnabled(point: ControlPointEntity) {
        viewModelScope.launch {
            repository.updateControlPoint(point.copy(enabled = !point.enabled))
            recompute()
        }
    }

    private suspend fun recompute() {
        val id = projectId ?: return
        val pts = repository.getControlPoints(id).filter { it.enabled }
        if (pts.isEmpty()) {
            _report.value = null
            return
        }
        val pairs = pts.map { it.toPair() }
        val loc = Localization.fit(pairs)
        if (loc == null) {
            _report.value = null
            return
        }
        val res = Localization.residuals(loc, pairs)
        _report.value = FitReport(
            scale = loc.scale,
            rotationDegrees = loc.rotationDegrees,
            verticalShift = loc.verticalShift,
            residuals = pts.map { it.label }.zip(res),
            maxResidual = res.maxOrNull() ?: 0.0,
            rmsResidual = Math.sqrt(res.sumOf { it * it } / res.size),
            usedPoints = pts.size
        )
    }

    fun applyCalibration() {
        val id = projectId ?: return
        viewModelScope.launch {
            val pairs = repository.getControlPoints(id).filter { it.enabled }.map { it.toPair() }
            val loc = Localization.fit(pairs)
            if (loc == null) {
                _message.value = "S'ka pika kontrolli për të llogaritur."
                return@launch
            }
            SurveyEngine.setLocalization(loc)
            repository.saveLocalization(
                LocalizationEntity(id, loc.a, loc.b, loc.tx, loc.ty, loc.verticalShift)
            )
            _applied.value = true
            _message.value = "Kalibrimi u aplikua për këtë projekt."
        }
    }

    fun clearCalibration() {
        val id = projectId ?: return
        viewModelScope.launch {
            SurveyEngine.clearLocalization()
            repository.clearLocalization(id)
            _applied.value = false
            _message.value = "Kalibrimi u hoq. Po punohet në rrjetin kombëtar."
        }
    }

    fun consumeMessage() {
        _message.value = null
    }

    private fun ControlPointEntity.toPair() = ControlPointPair(
        label = label,
        measured = GridXY(measuredEasting, measuredNorthing),
        measuredHeight = measuredHeight,
        known = GridXY(knownEasting, knownNorthing),
        knownHeight = knownHeight
    )
}
