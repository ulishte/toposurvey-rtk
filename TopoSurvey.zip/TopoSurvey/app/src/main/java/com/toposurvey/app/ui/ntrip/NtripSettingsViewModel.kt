package com.toposurvey.app.ui.ntrip

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.toposurvey.app.SurveyEngine
import com.toposurvey.app.gnss.NtripSettings
import com.toposurvey.app.gnss.NtripState
import kotlinx.coroutines.flow.StateFlow

class NtripSettingsViewModel(application: Application) : AndroidViewModel(application) {
    val state: StateFlow<NtripState> = SurveyEngine.ntrip.state

    fun connect(host: String, port: Int, mountpoint: String, user: String, pass: String) {
        SurveyEngine.startCorrections(NtripSettings(host = host, port = port, mountpoint = mountpoint, username = user, password = pass))
    }

    fun disconnect() = SurveyEngine.ntrip.disconnect()
}
