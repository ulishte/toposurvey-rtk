package com.toposurvey.app.geo

import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/** Result of an inverse computation between two grid points. */
data class InverseResult(
    val distance: Double,
    val bearingDegrees: Double,
    val deltaNorth: Double,
    val deltaEast: Double,
    val deltaHeight: Double?
)

/**
 * Position of a point relative to a straight alignment.
 *
 * [station] is the chainage measured along the line from its start (it can be
 * negative before the start, or greater than [lineLength] past the end).
 * [offset] is positive to the RIGHT of the direction of travel, which is the
 * convention used on every set of road drawings.
 */
data class StationOffset(
    val station: Double,
    val offset: Double,
    val lineLength: Double,
    val lineBearingDegrees: Double
) {
    val isRight: Boolean get() = offset >= 0
    val beyondEnd: Boolean get() = station > lineLength
    val beforeStart: Boolean get() = station < 0
}

/** Area/perimeter of a closed figure in grid coordinates. */
data class AreaResult(
    val areaSquareMetres: Double,
    val perimetreMetres: Double,
    val vertexCount: Int
) {
    val areaHectares: Double get() = areaSquareMetres / 10_000.0
    /** Dynym (dynym/dylym) = 1000 m², the unit used day to day in Albania. */
    val areaDynym: Double get() = areaSquareMetres / 1_000.0
}

/**
 * Plane coordinate geometry on the project grid. Working in projected
 * coordinates (rather than on the ellipsoid) is what surveyors expect: it
 * matches the numbers on the drawings and is what the area in a cadastral
 * document refers to.
 */
object Cogo {

    /** Grid bearing measured clockwise from grid north, in [0,360). */
    fun bearing(fromN: Double, fromE: Double, toN: Double, toE: Double): Double =
        (Math.toDegrees(atan2(toE - fromE, toN - fromN)) + 360.0) % 360.0

    fun inverse(
        fromN: Double, fromE: Double, fromH: Double?,
        toN: Double, toE: Double, toH: Double?
    ): InverseResult {
        val dN = toN - fromN
        val dE = toE - fromE
        return InverseResult(
            distance = hypot(dN, dE),
            bearingDegrees = bearing(fromN, fromE, toN, toE),
            deltaNorth = dN,
            deltaEast = dE,
            deltaHeight = if (fromH != null && toH != null) toH - fromH else null
        )
    }

    /** Forward/radiation: new point from a start point, bearing and distance. */
    fun forward(fromN: Double, fromE: Double, bearingDegrees: Double, distance: Double): GridXY {
        val rad = Math.toRadians(bearingDegrees)
        return GridXY(
            easting = fromE + distance * sin(rad),
            northing = fromN + distance * cos(rad)
        )
    }

    /**
     * Project a point onto a straight alignment defined by its start and end.
     * Returns null for a zero-length line.
     */
    fun stationOffset(
        startN: Double, startE: Double,
        endN: Double, endE: Double,
        pointN: Double, pointE: Double
    ): StationOffset? {
        val dN = endN - startN
        val dE = endE - startE
        val length = hypot(dN, dE)
        if (length == 0.0) return null

        val uN = dN / length
        val uE = dE / length
        val vN = pointN - startN
        val vE = pointE - startE

        return StationOffset(
            station = vN * uN + vE * uE,
            offset = vE * uN - vN * uE,
            lineLength = length,
            lineBearingDegrees = bearing(startN, startE, endN, endE)
        )
    }

    /** The point on the alignment at a given chainage. */
    fun pointAtStation(
        startN: Double, startE: Double,
        endN: Double, endE: Double,
        station: Double
    ): GridXY? {
        val dN = endN - startN
        val dE = endE - startE
        val length = hypot(dN, dE)
        if (length == 0.0) return null
        return GridXY(
            easting = startE + dE / length * station,
            northing = startN + dN / length * station
        )
    }

    /**
     * Shoelace (Gauss) area of the polygon through [vertices] in order, plus its
     * perimeter. The polygon is closed automatically; the area is unsigned so
     * the digitising direction does not matter.
     */
    fun area(vertices: List<GridXY>): AreaResult? {
        if (vertices.size < 3) return null
        var twiceArea = 0.0
        var perimetre = 0.0
        for (i in vertices.indices) {
            val a = vertices[i]
            val b = vertices[(i + 1) % vertices.size]
            twiceArea += a.easting * b.northing - b.easting * a.northing
            perimetre += hypot(b.easting - a.easting, b.northing - a.northing)
        }
        return AreaResult(
            areaSquareMetres = abs(twiceArea) / 2.0,
            perimetreMetres = perimetre,
            vertexCount = vertices.size
        )
    }

    /** Degrees -> "DDD° MM' SS.ss"" for reporting bearings the traditional way. */
    fun toDms(degrees: Double): String {
        val d = abs(degrees)
        val deg = d.toInt()
        val minFull = (d - deg) * 60.0
        val min = minFull.toInt()
        val sec = (minFull - min) * 60.0
        val sign = if (degrees < 0) "-" else ""
        return "$sign$deg° $min' ${"%.2f".format(sec)}\""
    }
}
