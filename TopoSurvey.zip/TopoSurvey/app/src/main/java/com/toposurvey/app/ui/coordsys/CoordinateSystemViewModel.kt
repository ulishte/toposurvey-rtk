package com.toposurvey.app.ui.coordsys

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.toposurvey.app.SurveyEngine
import com.toposurvey.app.TopoSurveyApp
import com.toposurvey.app.geo.CoordinateSystem
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class CoordinateSystemViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as TopoSurveyApp).repository

    val presets: List<CoordinateSystem> = CoordinateSystem.PRESETS
    val active: StateFlow<CoordinateSystem> = SurveyEngine.coordinateSystem

    fun select(system: CoordinateSystem) {
        SurveyEngine.setCoordinateSystemByName(system.name)
        val projectId = SurveyEngine.activeProjectId ?: return
        viewModelScope.launch { repository.setCoordinateSystem(projectId, system.name) }
    }

    fun describe(cs: CoordinateSystem): String {
        val proj = cs.projection ?: return "Gjeografike (pa projeksion) · ${cs.ellipsoid.name}"
        return buildString {
            append("Transverse Mercator · ${cs.ellipsoid.name}\n")
            append("Meridiani qendror ${proj.centralMeridian}°  ·  k0 ${proj.scaleFactor}\n")
            append("False E ${proj.falseEasting.toInt()}  ·  False N ${proj.falseNorthing.toInt()}")
        }
    }
}
