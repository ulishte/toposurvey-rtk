package com.toposurvey.app.ui.calc

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController

@Composable
fun CalcScreen(navController: NavHostController, viewModel: CalcViewModel = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = tab) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Sipërfaqe") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Inverse") })
            Tab(selected = tab == 2, onClick = { tab = 2 }, text = { Text("Radiacion") })
        }
        when (tab) {
            0 -> AreaTab(viewModel)
            1 -> InverseTab(viewModel)
            else -> ForwardTab(viewModel)
        }
    }
}

@Composable
private fun AreaTab(viewModel: CalcViewModel) {
    val points by viewModel.points.collectAsState()
    val selected by viewModel.selected.collectAsState()
    val result by viewModel.areaResult.collectAsState()

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Sipërfaqe & Perimetër", style = MaterialTheme.typography.titleMedium)
        Text(
            "Zgjidh pikat sipas radhës së kufirit. Poligoni mbyllet vetvetiu.",
            style = MaterialTheme.typography.bodySmall
        )

        result?.let { r ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("${"%.2f".format(r.areaSquareMetres)} m²", style = MaterialTheme.typography.headlineSmall)
                    Text("${"%.3f".format(r.areaDynym)} dynym  ·  ${"%.4f".format(r.areaHectares)} ha")
                    Text("Perimetri: ${"%.3f".format(r.perimetreMetres)} m")
                    Text("Kulme: ${r.vertexCount}", style = MaterialTheme.typography.bodySmall)
                }
            }
        } ?: Text("Zgjidh të paktën 3 pika.", style = MaterialTheme.typography.bodySmall)

        if (selected.isNotEmpty()) {
            OutlinedButton(onClick = { viewModel.clearSelection() }, modifier = Modifier.fillMaxWidth()) {
                Text("Pastro zgjedhjen (${selected.size})")
            }
        }

        points.forEach { p ->
            val index = selected.indexOfFirst { it.id == p.id }
            Card(modifier = Modifier.fillMaxWidth()) {
                Row(
                    Modifier.padding(12.dp).fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text("${p.code} - ${p.description}")
                        if (index >= 0) {
                            Text("Rendi: ${index + 1}", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Button(onClick = { viewModel.toggle(p) }) {
                        Text(if (index >= 0) "Hiq" else "Shto")
                    }
                }
            }
        }
    }
}

@Composable
private fun InverseTab(viewModel: CalcViewModel) {
    val result by viewModel.inverseResult.collectAsState()
    var n1 by remember { mutableStateOf("") }
    var e1 by remember { mutableStateOf("") }
    var h1 by remember { mutableStateOf("") }
    var n2 by remember { mutableStateOf("") }
    var e2 by remember { mutableStateOf("") }
    var h2 by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Llogaritje Inverse", style = MaterialTheme.typography.titleMedium)
        Text("Distanca dhe azimuti mes dy pikave.", style = MaterialTheme.typography.bodySmall)

        Text("Pika 1", style = MaterialTheme.typography.titleSmall)
        CoordRow(n1, { n1 = it }, e1, { e1 = it }, h1, { h1 = it })
        OutlinedButton(onClick = {
            viewModel.useCurrentPositionAsStart()?.let { (n, e) -> n1 = n; e1 = e }
        }) { Text("Merr pozicionin aktual") }

        Text("Pika 2", style = MaterialTheme.typography.titleSmall)
        CoordRow(n2, { n2 = it }, e2, { e2 = it }, h2, { h2 = it })
        OutlinedButton(onClick = {
            viewModel.useCurrentPositionAsStart()?.let { (n, e) -> n2 = n; e2 = e }
        }) { Text("Merr pozicionin aktual") }

        Button(
            onClick = { viewModel.inverse(n1, e1, h1, n2, e2, h2) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Llogarit") }

        result?.let { r ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("Distanca: ${"%.4f".format(r.distance)} m", style = MaterialTheme.typography.titleMedium)
                    Text("Azimuti: ${"%.4f".format(r.bearingDegrees)}°")
                    Text("           ${viewModel.dms(r.bearingDegrees)}")
                    Text("ΔN ${"%.4f".format(r.deltaNorth)}   ΔE ${"%.4f".format(r.deltaEast)}")
                    r.deltaHeight?.let { Text("ΔH ${"%.4f".format(it)} m") }
                }
            }
        }
    }
}

@Composable
private fun ForwardTab(viewModel: CalcViewModel) {
    val result by viewModel.forwardResult.collectAsState()
    var n by remember { mutableStateOf("") }
    var e by remember { mutableStateOf("") }
    var bearing by remember { mutableStateOf("") }
    var distance by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Radiacion (pikë e re)", style = MaterialTheme.typography.titleMedium)
        Text("Pikë e re nga azimuti dhe distanca.", style = MaterialTheme.typography.bodySmall)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Num(n, { n = it }, "N fillestar", Modifier.weight(1f))
            Num(e, { e = it }, "E fillestar", Modifier.weight(1f))
        }
        OutlinedButton(onClick = {
            viewModel.useCurrentPositionAsStart()?.let { (cn, ce) -> n = cn; e = ce }
        }) { Text("Merr pozicionin aktual") }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Num(bearing, { bearing = it }, "Azimuti (°)", Modifier.weight(1f))
            Num(distance, { distance = it }, "Distanca (m)", Modifier.weight(1f))
        }

        Button(
            onClick = { viewModel.forward(n, e, bearing, distance) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Llogarit") }

        result?.let { r ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text("N ${"%.4f".format(r.northing)}", style = MaterialTheme.typography.titleMedium)
                    Text("E ${"%.4f".format(r.easting)}", style = MaterialTheme.typography.titleMedium)
                }
            }
        }
    }
}

@Composable
private fun CoordRow(
    n: String, onN: (String) -> Unit,
    e: String, onE: (String) -> Unit,
    h: String, onH: (String) -> Unit
) {
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Num(n, onN, "N", Modifier.weight(1f))
        Num(e, onE, "E", Modifier.weight(1f))
        Num(h, onH, "H", Modifier.weight(1f))
    }
}

@Composable
private fun Num(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier
    )
}
