package com.toposurvey.app.gnss

import kotlin.math.floor

/**
 * Minimal, dependency-free NMEA-0183 parser for the sentences a GNSS rover
 * streams over Bluetooth SPP: GGA (position + fix quality) and RMC (time/date,
 * course/speed - useful later for heading-based stakeout arrows).
 *
 * Supports any talker id (GP, GN, GL, GA, GB/BD, ...) since modern multi-constellation
 * receivers usually send GN.
 */
object NmeaParser {

    /** Returns a GnssFix if [line] is a valid, checksum-correct GGA sentence with a fix, else null. */
    fun parseGga(line: String): GnssFix? {
        val sentence = line.trim()
        if (!isValidChecksum(sentence)) return null
        val body = sentence.substringBefore('*').removePrefix("$")
        val fields = body.split(",")
        if (fields.size < 15) return null
        val talkerAndType = fields[0]
        if (!talkerAndType.endsWith("GGA")) return null

        val utcTime = fields[1].toDoubleOrNull() ?: 0.0
        val lat = nmeaCoordToDecimal(fields[2], fields[3]) ?: return null
        val lon = nmeaCoordToDecimal(fields[4], fields[5]) ?: return null
        val quality = fields[6].toIntOrNull() ?: 0
        val sats = fields[7].toIntOrNull() ?: 0
        val hdop = fields[8].toDoubleOrNull() ?: 0.0
        val altitude = fields[9].toDoubleOrNull() ?: 0.0
        val geoidSep = fields[11].toDoubleOrNull() ?: 0.0
        val ageOfDiff = fields[13].toDoubleOrNull()

        return GnssFix(
            latitude = lat,
            longitude = lon,
            ellipsoidalHeight = altitude + geoidSep,
            orthometricHeight = altitude,
            geoidSeparation = geoidSep,
            fixQuality = FixQuality.fromCode(quality),
            satellites = sats,
            hdop = hdop,
            ageOfCorrectionsSeconds = ageOfDiff,
            utcTimeOfDaySeconds = utcTime,
            rawGga = sentence
        )
    }

    /** ddmm.mmmm / dddmm.mmmm + hemisphere letter -> signed decimal degrees. */
    private fun nmeaCoordToDecimal(raw: String, hemisphere: String): Double? {
        if (raw.isBlank()) return null
        val value = raw.toDoubleOrNull() ?: return null
        val degrees = floor(value / 100.0)
        val minutes = value - degrees * 100.0
        var decimal = degrees + minutes / 60.0
        if (hemisphere == "S" || hemisphere == "W") decimal = -decimal
        return decimal
    }

    private fun isValidChecksum(sentence: String): Boolean {
        val starIndex = sentence.indexOf('*')
        if (starIndex == -1 || starIndex + 3 > sentence.length) return false
        val payload = sentence.substring(1, starIndex)
        val expected = sentence.substring(starIndex + 1, starIndex + 3).toIntOrNull(16) ?: return false
        var checksum = 0
        for (c in payload) checksum = checksum xor c.code
        return checksum == expected
    }
}
