package com.toposurvey.app.ui.linestake

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.toposurvey.app.SurveyEngine
import com.toposurvey.app.TopoSurveyApp
import com.toposurvey.app.data.SurveyPointEntity
import com.toposurvey.app.geo.Cogo
import com.toposurvey.app.geo.GridResult
import com.toposurvey.app.geo.StationOffset
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn

/** The alignment being staked, in project grid coordinates. */
data class StakeLine(
    val startN: Double,
    val startE: Double,
    val endN: Double,
    val endE: Double,
    val startHeight: Double? = null,
    val endHeight: Double? = null
)

class LineStakeViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as TopoSurveyApp).repository
    private val projectId = SurveyEngine.activeProjectId

    val currentGrid: StateFlow<GridResult?> = SurveyEngine.currentGrid

    val points: StateFlow<List<SurveyPointEntity>> =
        (if (projectId != null) repository.observePoints(projectId) else flowOf(emptyList()))
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _line = MutableStateFlow<StakeLine?>(null)
    val line: StateFlow<StakeLine?> = _line

    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message

    /** Points picked from the library to define the alignment. */
    private val _picked = MutableStateFlow<List<SurveyPointEntity>>(emptyList())
    val picked: StateFlow<List<SurveyPointEntity>> = _picked

    fun pick(point: SurveyPointEntity) {
        val current = _picked.value
        _picked.value = when {
            current.any { it.id == point.id } -> current.filterNot { it.id == point.id }
            current.size >= 2 -> listOf(current[1], point)
            else -> current + point
        }
        buildFromPicked()
    }

    private fun buildFromPicked() {
        val p = _picked.value
        if (p.size < 2) {
            _line.value = null
            return
        }
        val a = SurveyEngine.project(p[0].latitude, p[0].longitude, p[0].ellipsoidalHeight)
        val b = SurveyEngine.project(p[1].latitude, p[1].longitude, p[1].ellipsoidalHeight)
        if (a == null || b == null) {
            _message.value = "Sistemi aktual s'ka projeksion."
            return
        }
        _line.value = StakeLine(a.northing, a.easting, b.northing, b.easting, a.height, b.height)
    }

    fun setManualLine(
        startN: String, startE: String, endN: String, endE: String,
        startH: String, endH: String
    ) {
        val sn = parse(startN); val se = parse(startE)
        val en = parse(endN); val ee = parse(endE)
        if (sn == null || se == null || en == null || ee == null) {
            _message.value = "Plotëso koordinatat e fillimit dhe të fundit."
            return
        }
        _picked.value = emptyList()
        _line.value = StakeLine(sn, se, en, ee, parse(startH), parse(endH))
        _message.value = null
    }

    fun clearLine() {
        _line.value = null
        _picked.value = emptyList()
    }

    fun stationOffset(current: GridResult, line: StakeLine): StationOffset? =
        Cogo.stationOffset(
            line.startN, line.startE, line.endN, line.endE,
            current.northing, current.easting
        )

    /**
     * Design height at a chainage, interpolated linearly between the two ends.
     * Null when either end has no height, in which case no cut/fill is shown.
     */
    fun designHeight(line: StakeLine, so: StationOffset): Double? {
        val h0 = line.startHeight ?: return null
        val h1 = line.endHeight ?: return null
        if (so.lineLength == 0.0) return h0
        val t = so.station / so.lineLength
        return h0 + (h1 - h0) * t
    }

    fun consumeMessage() { _message.value = null }

    private fun parse(s: String): Double? = s.replace(",", ".").toDoubleOrNull()
}
