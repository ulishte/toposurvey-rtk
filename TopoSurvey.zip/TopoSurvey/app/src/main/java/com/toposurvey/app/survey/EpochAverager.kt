package com.toposurvey.app.survey

import com.toposurvey.app.gnss.FixQuality
import com.toposurvey.app.gnss.GnssFix
import kotlin.math.sqrt

/** Result of averaging several GNSS epochs on one mark. */
data class AveragedPosition(
    val latitude: Double,
    val longitude: Double,
    val ellipsoidalHeight: Double,
    val epochs: Int,
    val worstFix: FixQuality,
    val satellites: Int,
    val hdop: Double,
    /** Spread of the averaged epochs in metres - a direct quality indicator. */
    val horizontalRmsMetres: Double,
    val verticalRmsMetres: Double,
    val timestampMillis: Long
)

object EpochAverager {

    private const val METRES_PER_DEGREE_LAT = 111_320.0

    fun average(fixes: List<GnssFix>): AveragedPosition? {
        if (fixes.isEmpty()) return null

        val n = fixes.size
        val lat = fixes.sumOf { it.latitude } / n
        val lon = fixes.sumOf { it.longitude } / n
        val h = fixes.sumOf { it.ellipsoidalHeight } / n

        val cosLat = Math.cos(Math.toRadians(lat))
        var sumSqH = 0.0
        var sumSqV = 0.0
        for (f in fixes) {
            val dN = (f.latitude - lat) * METRES_PER_DEGREE_LAT
            val dE = (f.longitude - lon) * METRES_PER_DEGREE_LAT * cosLat
            sumSqH += dN * dN + dE * dE
            val dH = f.ellipsoidalHeight - h
            sumSqV += dH * dH
        }

        return AveragedPosition(
            latitude = lat,
            longitude = lon,
            ellipsoidalHeight = h,
            epochs = n,
            worstFix = fixes.minByOrNull { qualityRank(it.fixQuality) }?.fixQuality ?: FixQuality.UNKNOWN,
            satellites = fixes.minOf { it.satellites },
            hdop = fixes.maxOf { it.hdop },
            horizontalRmsMetres = sqrt(sumSqH / n),
            verticalRmsMetres = sqrt(sumSqV / n),
            timestampMillis = fixes.last().timestampMillis
        )
    }

    /** Higher is better, so the minimum is the worst epoch in the set. */
    private fun qualityRank(q: FixQuality): Int = when (q) {
        FixQuality.RTK_FIXED -> 5
        FixQuality.RTK_FLOAT -> 4
        FixQuality.DGPS -> 3
        FixQuality.PPS -> 2
        FixQuality.GPS -> 1
        else -> 0
    }

    /** Survey-grade means an RTK fixed solution; anything else is a warning. */
    fun isSurveyGrade(q: FixQuality): Boolean = q == FixQuality.RTK_FIXED
}
