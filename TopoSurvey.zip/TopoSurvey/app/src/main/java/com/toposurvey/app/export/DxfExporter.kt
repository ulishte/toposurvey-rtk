package com.toposurvey.app.export

import android.content.Context
import com.toposurvey.app.data.SurveyPointEntity
import com.toposurvey.app.geo.CoordinateSystem
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Minimal DXF R12 writer: one POINT plus a TEXT label per surveyed point.
 *
 * R12 ASCII is deliberately chosen because every CAD package (AutoCAD, Civil 3D,
 * BricsCAD, QGIS, ZWCAD...) reads it without complaint, and it is simple enough
 * to emit correctly by hand.
 */
object DxfExporter {

    fun export(
        context: Context,
        projectName: String,
        points: List<SurveyPointEntity>,
        system: CoordinateSystem,
        textHeight: Double = 0.5
    ): File {
        val dir = File(context.getExternalFilesDir(null), "Export").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val safe = projectName.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val file = File(dir, "${safe}_$stamp.dxf")

        file.bufferedWriter().use { w ->
            fun code(code: Int, value: String) {
                w.write(code.toString()); w.newLine(); w.write(value); w.newLine()
            }
            fun num(v: Double) = "%.4f".format(Locale.US, v)

            // --- header ---
            code(0, "SECTION"); code(2, "ENTITIES")

            points.forEach { p ->
                val g = system.fromWgs84(p.latitude, p.longitude, p.ellipsoidalHeight) ?: return@forEach

                code(0, "POINT")
                code(8, "PIKA")
                code(10, num(g.easting))
                code(20, num(g.northing))
                code(30, num(g.height))

                val label = buildString {
                    append(p.code)
                    if (p.description.isNotBlank()) append(" ").append(p.description)
                }
                code(0, "TEXT")
                code(8, "ETIKETA")
                code(10, num(g.easting + textHeight * 0.6))
                code(20, num(g.northing + textHeight * 0.6))
                code(30, num(g.height))
                code(40, num(textHeight))
                code(1, label)
            }

            code(0, "ENDSEC")
            code(0, "EOF")
        }
        return file
    }
}
