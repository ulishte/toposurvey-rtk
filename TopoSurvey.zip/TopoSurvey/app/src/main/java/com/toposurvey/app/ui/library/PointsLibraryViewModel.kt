package com.toposurvey.app.ui.library

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.toposurvey.app.SurveyEngine
import com.toposurvey.app.TopoSurveyApp
import com.toposurvey.app.data.SurveyPointEntity
import com.toposurvey.app.export.CsvExporter
import com.toposurvey.app.geo.CoordinateSystem
import com.toposurvey.app.geo.GridResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class PointsLibraryViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as TopoSurveyApp).repository
    private val projectId = SurveyEngine.activeProjectId

    val coordinateSystem: StateFlow<CoordinateSystem> = SurveyEngine.coordinateSystem

    val points: StateFlow<List<SurveyPointEntity>> =
        (if (projectId != null) repository.observePoints(projectId) else flowOf(emptyList()))
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _lastExportedFile = MutableStateFlow<File?>(null)
    val lastExportedFile: StateFlow<File?> = _lastExportedFile

    fun gridFor(point: SurveyPointEntity): GridResult? =
        coordinateSystem.value.fromWgs84(point.latitude, point.longitude, point.ellipsoidalHeight)

    fun deletePoint(point: SurveyPointEntity) {
        viewModelScope.launch { repository.deletePoint(point) }
    }

    fun exportCsv() {
        val id = projectId ?: return
        viewModelScope.launch {
            val project = repository.getProject(id)
            val pts = repository.getPointsOnce(id)
            val file = CsvExporter.export(
                getApplication(),
                project?.name ?: "projekt",
                pts,
                coordinateSystem.value
            )
            _lastExportedFile.value = file
        }
    }
}
