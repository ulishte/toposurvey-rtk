package com.toposurvey.app.ui.library

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.toposurvey.app.SurveyEngine
import com.toposurvey.app.TopoSurveyApp
import com.toposurvey.app.data.SurveyPointEntity
import com.toposurvey.app.export.CsvExporter
import com.toposurvey.app.export.DxfExporter
import com.toposurvey.app.export.ExportSharing
import com.toposurvey.app.export.KmlExporter
import com.toposurvey.app.geo.CoordinateSystem
import com.toposurvey.app.geo.GridResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class PointsLibraryViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as TopoSurveyApp).repository
    private val projectId = SurveyEngine.activeProjectId

    val coordinateSystem: StateFlow<CoordinateSystem> = SurveyEngine.coordinateSystem

    val points: StateFlow<List<SurveyPointEntity>> =
        (if (projectId != null) repository.observePoints(projectId) else flowOf(emptyList()))
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _lastExportedFile = MutableStateFlow<File?>(null)
    val lastExportedFile: StateFlow<File?> = _lastExportedFile

    fun gridFor(point: SurveyPointEntity): GridResult? =
        coordinateSystem.value.fromWgs84(point.latitude, point.longitude, point.ellipsoidalHeight)

    fun updatePoint(point: SurveyPointEntity, code: String, description: String) {
        viewModelScope.launch {
            repository.updatePoint(point.copy(code = code.ifBlank { point.code }, description = description))
        }
    }

    fun deletePoint(point: SurveyPointEntity) {
        viewModelScope.launch { repository.deletePoint(point) }
    }

    fun exportCsv() = export { name, pts -> CsvExporter.export(getApplication(), name, pts, coordinateSystem.value) }

    fun exportDxf() = export { name, pts -> DxfExporter.export(getApplication(), name, pts, coordinateSystem.value) }

    fun exportKml() = export { name, pts -> KmlExporter.export(getApplication(), name, pts) }

    private fun export(block: (String, List<SurveyPointEntity>) -> File) {
        val id = projectId ?: return
        viewModelScope.launch {
            val project = repository.getProject(id)
            val pts = repository.getPointsOnce(id)
            if (pts.isEmpty()) return@launch
            _lastExportedFile.value = block(project?.name ?: "projekt", pts)
        }
    }

    fun shareLast() {
        _lastExportedFile.value?.let { ExportSharing.share(getApplication(), it) }
    }
}
