package com.toposurvey.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Fitted site calibration for a project (one row per project). */
@Entity(tableName = "localizations")
data class LocalizationEntity(
    @PrimaryKey val projectId: Long,
    val a: Double,
    val b: Double,
    val tx: Double,
    val ty: Double,
    val verticalShift: Double
)
