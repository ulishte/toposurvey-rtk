package com.toposurvey.app.ui.nav

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.toposurvey.app.ui.device.DeviceConnectScreen
import com.toposurvey.app.ui.home.HomeScreen
import com.toposurvey.app.ui.library.PointsLibraryScreen
import com.toposurvey.app.ui.ntrip.NtripSettingsScreen
import com.toposurvey.app.ui.stakeout.StakeoutScreen
import com.toposurvey.app.ui.survey.PointSurveyScreen

object Routes {
    const val HOME = "home"
    const val DEVICE_CONNECT = "device_connect"
    const val POINT_SURVEY = "point_survey"
    const val POINTS_LIBRARY = "points_library"
    const val STAKEOUT = "stakeout"
    const val NTRIP_SETTINGS = "ntrip_settings"
}

@Composable
fun AppNavHost(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Routes.HOME) {
        composable(Routes.HOME) { HomeScreen(navController) }
        composable(Routes.DEVICE_CONNECT) { DeviceConnectScreen(navController) }
        composable(Routes.POINT_SURVEY) { PointSurveyScreen(navController) }
        composable(Routes.POINTS_LIBRARY) { PointsLibraryScreen(navController) }
        composable(Routes.STAKEOUT) { StakeoutScreen(navController) }
        composable(Routes.NTRIP_SETTINGS) { NtripSettingsScreen(navController) }
    }
}
