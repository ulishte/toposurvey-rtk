package com.toposurvey.app.gnss

/** NMEA GGA fix quality indicator. RTK_FIXED is the ~1-2cm survey-grade fix. */
enum class FixQuality(val code: Int) {
    INVALID(0),
    GPS(1),
    DGPS(2),
    PPS(3),
    RTK_FIXED(4),
    RTK_FLOAT(5),
    ESTIMATED(6),
    MANUAL(7),
    SIMULATION(8),
    UNKNOWN(-1);

    companion object {
        fun fromCode(code: Int): FixQuality = entries.firstOrNull { it.code == code } ?: UNKNOWN
    }
}

/** A single decoded position update from the rover. */
data class GnssFix(
    val latitude: Double,
    val longitude: Double,
    val ellipsoidalHeight: Double,
    /** Orthometric height (above mean sea level) as reported in the GGA. */
    val orthometricHeight: Double,
    /** Geoid separation N: ellipsoidal = orthometric + N. */
    val geoidSeparation: Double,
    val fixQuality: FixQuality,
    val satellites: Int,
    val hdop: Double,
    val ageOfCorrectionsSeconds: Double?,
    val utcTimeOfDaySeconds: Double,
    val timestampMillis: Long = System.currentTimeMillis(),
    /** Raw sentence, kept so it can be forwarded to an NTRIP caster that requires a GGA string. */
    val rawGga: String
)
