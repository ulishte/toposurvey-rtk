package com.toposurvey.app.geo

import kotlin.math.sqrt

/**
 * Reference ellipsoid. [a] is the semi-major axis in metres and [invF] the
 * inverse flattening (1/f) as it is conventionally published.
 */
data class Ellipsoid(
    val name: String,
    val a: Double,
    val invF: Double
) {
    val f: Double get() = 1.0 / invF

    /** Semi-minor axis. */
    val b: Double get() = a * (1.0 - f)

    /** First eccentricity squared: e² = 2f - f². */
    val e2: Double get() = 2.0 * f - f * f

    /** Second eccentricity squared: e'² = e²/(1-e²). */
    val ep2: Double get() = e2 / (1.0 - e2)

    val e: Double get() = sqrt(e2)

    companion object {
        val WGS84 = Ellipsoid("WGS 84", 6378137.0, 298.257223563)
        val GRS80 = Ellipsoid("GRS 80", 6378137.0, 298.257222101)
        val INTERNATIONAL_1924 = Ellipsoid("International 1924 (Hayford)", 6378388.0, 297.0)
        val KRASSOVSKY_1940 = Ellipsoid("Krassovsky 1940", 6378245.0, 298.3)
        val BESSEL_1841 = Ellipsoid("Bessel 1841", 6377397.155, 299.1528128)
        val CLARKE_1866 = Ellipsoid("Clarke 1866", 6378206.4, 294.9786982)

        val ALL = listOf(WGS84, GRS80, INTERNATIONAL_1924, KRASSOVSKY_1940, BESSEL_1841, CLARKE_1866)
    }
}
