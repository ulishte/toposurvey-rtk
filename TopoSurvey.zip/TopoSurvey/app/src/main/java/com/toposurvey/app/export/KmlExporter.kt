package com.toposurvey.app.export

import android.content.Context
import com.toposurvey.app.data.SurveyPointEntity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * KML export for Google Earth. KML is always WGS84 lat/lon by specification,
 * so the raw GNSS values are written directly - no projection involved.
 */
object KmlExporter {

    fun export(context: Context, projectName: String, points: List<SurveyPointEntity>): File {
        val dir = File(context.getExternalFilesDir(null), "Export").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val safe = projectName.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val file = File(dir, "${safe}_$stamp.kml")

        file.bufferedWriter().use { w ->
            w.write("""<?xml version="1.0" encoding="UTF-8"?>""")
            w.newLine()
            w.write("""<kml xmlns="http://www.opengis.net/kml/2.2"><Document>""")
            w.newLine()
            w.write("<name>${escape(projectName)}</name>")
            w.newLine()
            points.forEach { p ->
                w.write("<Placemark>")
                w.write("<name>${escape(p.code)}</name>")
                if (p.description.isNotBlank()) {
                    w.write("<description>${escape(p.description)}</description>")
                }
                w.write("<Point><coordinates>")
                w.write(
                    "%.9f,%.9f,%.3f".format(
                        Locale.US, p.longitude, p.latitude, p.ellipsoidalHeight
                    )
                )
                w.write("</coordinates></Point></Placemark>")
                w.newLine()
            }
            w.write("</Document></kml>")
        }
        return file
    }

    private fun escape(s: String): String = s
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
}
