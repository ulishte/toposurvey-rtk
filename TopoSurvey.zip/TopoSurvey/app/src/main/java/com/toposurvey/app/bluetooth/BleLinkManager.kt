package com.toposurvey.app.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import java.util.UUID

/**
 * BLE (GATT) link for receivers that expose a serial-over-BLE service instead
 * of classic SPP - increasingly common on newer rovers and on phones/tablets
 * that no longer pair over SPP.
 *
 * Several vendors reuse the same well-known "UART" profiles, so the manager
 * probes for each in turn rather than hard-coding a single one.
 */
class BleLinkManager(private val scope: CoroutineScope) {

    companion object {
        /** Nordic UART Service - by far the most widely reused. */
        private val NUS_SERVICE: UUID = UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
        private val NUS_TX: UUID = UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E") // notify
        private val NUS_RX: UUID = UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E") // write

        /** HM-10 / CC254x style transparent serial. */
        private val HM10_SERVICE: UUID = UUID.fromString("0000FFE0-0000-1000-8000-00805F9B34FB")
        private val HM10_CHAR: UUID = UUID.fromString("0000FFE1-0000-1000-8000-00805F9B34FB")

        private val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805F9B34FB")

        private val PROFILES = listOf(
            Triple(NUS_SERVICE, NUS_TX, NUS_RX),
            Triple(HM10_SERVICE, HM10_CHAR, HM10_CHAR)
        )
    }

    private val _state = MutableStateFlow<BtLinkState>(BtLinkState.Disconnected)
    val state: StateFlow<BtLinkState> = _state

    private val _nmeaLines = MutableSharedFlow<String>(extraBufferCapacity = 64)
    val nmeaLines: SharedFlow<String> = _nmeaLines

    private var gatt: BluetoothGatt? = null
    private var writeCharacteristic: BluetoothGattCharacteristic? = null

    /** NMEA arrives in arbitrary chunks; reassemble complete lines here. */
    private val buffer = StringBuilder()

    @SuppressLint("MissingPermission")
    fun bondedDevices(context: Context): List<BluetoothDevice> {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return emptyList()
        return runCatching { adapter.bondedDevices.toList() }.getOrDefault(emptyList())
    }

    @SuppressLint("MissingPermission")
    fun connect(context: Context, device: BluetoothDevice) {
        disconnect()
        _state.value = BtLinkState.Connecting
        gatt = device.connectGatt(context, false, callback, BluetoothDevice.TRANSPORT_LE)
    }

    private val callback = object : BluetoothGattCallback() {

        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> g.discoverServices()
                BluetoothProfile.STATE_DISCONNECTED -> {
                    _state.value = BtLinkState.Disconnected
                    runCatching { g.close() }
                }
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                _state.value = BtLinkState.Error("Zbulimi i shërbimeve dështoi")
                return
            }

            for ((serviceUuid, notifyUuid, writeUuid) in PROFILES) {
                val service = g.getService(serviceUuid) ?: continue
                val notifyChar = service.getCharacteristic(notifyUuid) ?: continue

                g.setCharacteristicNotification(notifyChar, true)
                notifyChar.getDescriptor(CCCD)?.let { descriptor ->
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        g.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                    } else {
                        @Suppress("DEPRECATION")
                        descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        @Suppress("DEPRECATION")
                        g.writeDescriptor(descriptor)
                    }
                }

                writeCharacteristic = service.getCharacteristic(writeUuid)
                _state.value = BtLinkState.Connected(g.device.name ?: g.device.address)
                return
            }

            _state.value = BtLinkState.Error("Pajisja s'ofron shërbim serial BLE të njohur")
        }

        @Suppress("DEPRECATION")
        @Deprecated("Kept for Android 12 and older")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            handleIncoming(c.value)
        }

        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            c: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            handleIncoming(value)
        }
    }

    private fun handleIncoming(bytes: ByteArray?) {
        if (bytes == null) return
        buffer.append(String(bytes, Charsets.US_ASCII))
        while (true) {
            val newline = buffer.indexOfFirst { it == '\n' || it == '\r' }
            if (newline < 0) break
            val line = buffer.substring(0, newline).trim()
            buffer.delete(0, newline + 1)
            if (line.isNotEmpty()) _nmeaLines.tryEmit(line)
        }
        // Guard against a receiver that never sends a terminator.
        if (buffer.length > 4096) buffer.clear()
    }

    /** Forward RTCM corrections to the rover over the BLE write characteristic. */
    @SuppressLint("MissingPermission")
    fun sendCorrectionBytes(bytes: ByteArray) {
        val g = gatt ?: return
        val ch = writeCharacteristic ?: return
        // BLE payloads are small; split to stay within the default MTU.
        bytes.toList().chunked(20).forEach { chunk ->
            val payload = chunk.toByteArray()
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                g.writeCharacteristic(ch, payload, BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE)
            } else {
                @Suppress("DEPRECATION")
                ch.value = payload
                @Suppress("DEPRECATION")
                ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
                @Suppress("DEPRECATION")
                g.writeCharacteristic(ch)
            }
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnect() {
        runCatching { gatt?.disconnect() }
        runCatching { gatt?.close() }
        gatt = null
        writeCharacteristic = null
        buffer.clear()
        _state.value = BtLinkState.Disconnected
    }
}

private inline fun CharSequence.indexOfFirst(predicate: (Char) -> Boolean): Int {
    for (i in indices) if (predicate(this[i])) return i
    return -1
}
