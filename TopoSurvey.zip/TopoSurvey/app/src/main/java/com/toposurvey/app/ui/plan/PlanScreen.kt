package com.toposurvey.app.ui.plan

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import kotlin.math.max
import kotlin.math.min

/**
 * Simple plan view of the job. Deliberately dependency-free: no tiles, no
 * network, no API key - it draws the project's own grid coordinates, which is
 * what matters on site and works with no signal at all.
 *
 * Screen axes follow survey convention: north is up, east is right.
 */
@Composable
fun PlanScreen(navController: NavHostController, viewModel: PlanViewModel = viewModel()) {
    val entities by viewModel.points.collectAsState()
    val current by viewModel.currentGrid.collectAsState()

    val points = viewModel.planPoints(entities)

    var scale by remember { mutableFloatStateOf(0f) }   // 0 = auto-fit
    var panX by remember { mutableFloatStateOf(0f) }
    var panY by remember { mutableFloatStateOf(0f) }
    var autoFit by remember { mutableStateOf(true) }

    Column(modifier = Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Pamja e Punës", style = MaterialTheme.typography.headlineSmall)
        Text(
            "${points.size} pikë · veriu lart. Zmadho me dy gishta, lëviz me një gisht.",
            style = MaterialTheme.typography.bodySmall
        )

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .background(Color(0xFFF3F3F0))
                .pointerInput(Unit) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        autoFit = false
                        if (scale == 0f) scale = 1f
                        scale *= zoom
                        panX += pan.x
                        panY += pan.y
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val all = buildList {
                    addAll(points.map { it.easting to it.northing })
                    current?.let { add(it.easting to it.northing) }
                }
                if (all.isEmpty()) return@Canvas

                val minE = all.minOf { it.first }
                val maxE = all.maxOf { it.first }
                val minN = all.minOf { it.second }
                val maxN = all.maxOf { it.second }

                val spanE = (maxE - minE).coerceAtLeast(1.0)
                val spanN = (maxN - minN).coerceAtLeast(1.0)
                val margin = 0.12f
                val fit = min(
                    size.width * (1 - 2 * margin) / spanE.toFloat(),
                    size.height * (1 - 2 * margin) / spanN.toFloat()
                )
                val effectiveScale = if (autoFit || scale == 0f) fit else fit * scale
                val centreE = (minE + maxE) / 2.0
                val centreN = (minN + maxN) / 2.0

                fun toScreen(e: Double, n: Double): Offset = Offset(
                    x = (size.width / 2f) + ((e - centreE).toFloat() * effectiveScale) + panX,
                    y = (size.height / 2f) - ((n - centreN).toFloat() * effectiveScale) + panY
                )

                drawScaleBar(effectiveScale)

                // surveyed points
                points.forEach { p ->
                    val o = toScreen(p.easting, p.northing)
                    drawCircle(Color(0xFF1B5E20), radius = 7f, center = o)
                    drawContext.canvas.nativeCanvas.apply {
                        drawText(p.label, o.x + 10f, o.y - 8f, android.graphics.Paint().apply {
                            color = android.graphics.Color.DKGRAY
                            textSize = 30f
                        })
                    }
                }

                // live rover position
                current?.let { c ->
                    val o = toScreen(c.easting, c.northing)
                    drawCircle(Color(0xFFD32F2F), radius = 14f, center = o, style = Stroke(width = 4f))
                    drawCircle(Color(0xFFD32F2F), radius = 5f, center = o)
                }
            }
        }

        current?.let { c ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(10.dp)) {
                    Text("Pozicioni: N ${"%.3f".format(c.northing)}  E ${"%.3f".format(c.easting)}")
                }
            }
        }

        OutlinedButton(
            onClick = { autoFit = true; scale = 0f; panX = 0f; panY = 0f },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Përshtat pamjen") }
    }
}

/** Draws a metric scale bar so distances on screen stay interpretable. */
private fun DrawScope.drawScaleBar(pixelsPerMetre: Float) {
    if (pixelsPerMetre <= 0f) return
    val candidates = listOf(1, 2, 5, 10, 20, 50, 100, 200, 500, 1000)
    val targetPx = size.width * 0.25f
    val metres = candidates.firstOrNull { it * pixelsPerMetre >= targetPx } ?: candidates.last()
    val barPx = metres * pixelsPerMetre
    val y = size.height - 30f
    val x0 = 20f
    val x1 = x0 + max(10f, min(barPx, size.width - 40f))
    drawLine(Color.DarkGray, Offset(x0, y), Offset(x1, y), strokeWidth = 4f)
    drawLine(Color.DarkGray, Offset(x0, y - 8f), Offset(x0, y + 8f), strokeWidth = 4f)
    drawLine(Color.DarkGray, Offset(x1, y - 8f), Offset(x1, y + 8f), strokeWidth = 4f)
    drawContext.canvas.nativeCanvas.drawText(
        "$metres m", x0, y - 14f,
        android.graphics.Paint().apply {
            color = android.graphics.Color.DKGRAY
            textSize = 30f
        }
    )
}
