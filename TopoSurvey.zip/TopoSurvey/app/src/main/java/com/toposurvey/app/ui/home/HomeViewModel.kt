package com.toposurvey.app.ui.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.toposurvey.app.SurveyEngine
import com.toposurvey.app.TopoSurveyApp
import com.toposurvey.app.bluetooth.BtLinkState
import com.toposurvey.app.data.SurveyProjectEntity
import com.toposurvey.app.gnss.GnssFix
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class HomeViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as TopoSurveyApp).repository

    val projects: StateFlow<List<SurveyProjectEntity>> = repository.observeProjects()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val linkState: StateFlow<BtLinkState> = SurveyEngine.bluetooth.state
    val currentFix: StateFlow<GnssFix?> = SurveyEngine.currentFix

    fun createProject(name: String) {
        viewModelScope.launch {
            val id = repository.createProject(name.ifBlank { "Projekti pa emër" })
            SurveyEngine.activeProjectId = id
        }
    }

    fun selectProject(id: Long) {
        SurveyEngine.activeProjectId = id
    }
}
