package com.toposurvey.app.ui.device

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.toposurvey.app.bluetooth.BtLinkState

/**
 * Lists paired (bonded) devices and connects over classic Bluetooth SPP.
 * Phase 2 TODO: add a live discovery/scan flow for unpaired rovers, and a
 * BLE path for receivers that only expose a GATT serial service.
 */
@SuppressLint("MissingPermission")
@Composable
fun DeviceConnectScreen(navController: NavHostController, viewModel: DeviceConnectViewModel = viewModel()) {
    val state by viewModel.linkState.collectAsState()
    val devices = viewModel.pairedDevices()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Lidhu me Rover-in", style = MaterialTheme.typography.headlineSmall)
        Text(
            when (state) {
                is BtLinkState.Disconnected -> "I shkëputur"
                is BtLinkState.Connecting -> "Duke u lidhur..."
                is BtLinkState.Connected -> "Lidhur me ${(state as BtLinkState.Connected).deviceName}"
                is BtLinkState.Error -> "Gabim: ${(state as BtLinkState.Error).message}"
            }
        )
        Text("Pajisje të çiftuara (Settings > Bluetooth duhet çiftuar rover-in më parë):")

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(devices) { device ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(device.name ?: "(pa emër)", style = MaterialTheme.typography.titleSmall)
                        Text(device.address, style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { viewModel.connect(device) }) { Text("Lidhu") }
                    }
                }
            }
        }

        Button(onClick = { viewModel.disconnect() }, modifier = Modifier.fillMaxWidth()) {
            Text("Shkëput")
        }
    }
}
