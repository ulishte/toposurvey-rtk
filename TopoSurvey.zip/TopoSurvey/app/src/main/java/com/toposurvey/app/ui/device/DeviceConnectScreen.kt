package com.toposurvey.app.ui.device

import android.annotation.SuppressLint
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.toposurvey.app.bluetooth.BtLinkState

/**
 * Connect to the rover over classic Bluetooth (SPP) or BLE. Both list bonded
 * devices, so the receiver should be paired once in Android settings first.
 */
@SuppressLint("MissingPermission")
@Composable
fun DeviceConnectScreen(navController: NavHostController, viewModel: DeviceConnectViewModel = viewModel()) {
    val state by viewModel.linkState.collectAsState()
    val mode by viewModel.mode.collectAsState()
    val devices = viewModel.pairedDevices()

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Lidhu me Rover-in", style = MaterialTheme.typography.headlineSmall)
        Text(
            when (val s = state) {
                is BtLinkState.Disconnected -> "I shkëputur"
                is BtLinkState.Connecting -> "Duke u lidhur..."
                is BtLinkState.Connected -> "Lidhur me ${s.deviceName}"
                is BtLinkState.Error -> "Gabim: ${s.message}"
            }
        )

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(
                selected = mode == LinkMode.SPP,
                onClick = { viewModel.setMode(LinkMode.SPP) },
                label = { Text("Bluetooth klasik") }
            )
            FilterChip(
                selected = mode == LinkMode.BLE,
                onClick = { viewModel.setMode(LinkMode.BLE) },
                label = { Text("BLE") }
            )
        }
        Text(
            if (mode == LinkMode.SPP) "Për shumicën e rover-ave RTK (profili serial SPP)."
            else "Për rover-at e rinj që përdorin serial mbi BLE.",
            style = MaterialTheme.typography.bodySmall
        )

        Text("Pajisje të çiftuara (çiftoji te Settings > Bluetooth):", style = MaterialTheme.typography.titleSmall)

        devices.forEach { device ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(device.name ?: "(pa emër)", style = MaterialTheme.typography.titleSmall)
                    Text(device.address, style = MaterialTheme.typography.bodySmall)
                    Button(onClick = { viewModel.connect(device) }) { Text("Lidhu") }
                }
            }
        }
        if (devices.isEmpty()) {
            Text("Asnjë pajisje e çiftuar.", style = MaterialTheme.typography.bodySmall)
        }

        OutlinedButton(onClick = { viewModel.disconnect() }, modifier = Modifier.fillMaxWidth()) {
            Text("Shkëput")
        }
    }
}
