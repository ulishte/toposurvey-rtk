package com.toposurvey.app.ui.plan

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.toposurvey.app.SurveyEngine
import com.toposurvey.app.TopoSurveyApp
import com.toposurvey.app.data.SurveyPointEntity
import com.toposurvey.app.geo.GridResult
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn

/** A point ready to draw: grid coordinates plus its label. */
data class PlanPoint(val label: String, val easting: Double, val northing: Double)

class PlanViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as TopoSurveyApp).repository
    private val projectId = SurveyEngine.activeProjectId

    val currentGrid: StateFlow<GridResult?> = SurveyEngine.currentGrid

    val points: StateFlow<List<SurveyPointEntity>> =
        (if (projectId != null) repository.observePoints(projectId) else flowOf(emptyList()))
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun planPoints(source: List<SurveyPointEntity>): List<PlanPoint> = source.mapNotNull { p ->
        val g = SurveyEngine.project(p.latitude, p.longitude, p.ellipsoidalHeight) ?: return@mapNotNull null
        PlanPoint(p.code, g.easting, g.northing)
    }
}
