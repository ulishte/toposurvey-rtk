package com.toposurvey.app.ui.home

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.toposurvey.app.bluetooth.BtLinkState
import com.toposurvey.app.ui.nav.Routes

@Composable
fun HomeScreen(navController: NavHostController, viewModel: HomeViewModel = viewModel()) {
    val projects by viewModel.projects.collectAsState()
    val linkState by viewModel.linkState.collectAsState()
    val fix by viewModel.currentFix.collectAsState()
    var newProjectName by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("TopoSurvey", style = MaterialTheme.typography.headlineMedium)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("Rover: ${statusText(linkState)}")
                Text(
                    fix?.let { "Fiks: ${it.fixQuality} · Sat: ${it.satellites} · HDOP: ${it.hdop}" }
                        ?: "Ende pa pozicion"
                )
            }
        }

        Button(onClick = { navController.navigate(Routes.DEVICE_CONNECT) }, modifier = Modifier.fillMaxWidth()) {
            Text("Lidhu me Rover-in (Bluetooth)")
        }
        Button(onClick = { navController.navigate(Routes.NTRIP_SETTINGS) }, modifier = Modifier.fillMaxWidth()) {
            Text("Korrigjime RTK (NTRIP)")
        }
        Button(onClick = { navController.navigate(Routes.POINT_SURVEY) }, modifier = Modifier.fillMaxWidth()) {
            Text("Rilevim Pikash")
        }
        Button(onClick = { navController.navigate(Routes.POINTS_LIBRARY) }, modifier = Modifier.fillMaxWidth()) {
            Text("Libraria e Pikave / Eksport")
        }
        Button(onClick = { navController.navigate(Routes.STAKEOUT) }, modifier = Modifier.fillMaxWidth()) {
            Text("Skedarizim (Stakeout)")
        }

        Text("Projektet", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(
            value = newProjectName,
            onValueChange = { newProjectName = it },
            label = { Text("Emri i projektit të ri") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(onClick = { viewModel.createProject(newProjectName); newProjectName = "" }) {
            Text("Krijo Projekt")
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(vertical = 8.dp)) {
            items(projects) { project ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text(project.name, style = MaterialTheme.typography.titleSmall)
                        Text(project.coordinateSystemName, style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { viewModel.selectProject(project.id) }) {
                            Text("Përdor këtë projekt")
                        }
                    }
                }
            }
        }
    }
}

private fun statusText(state: BtLinkState): String = when (state) {
    is BtLinkState.Disconnected -> "I shkëputur"
    is BtLinkState.Connecting -> "Duke u lidhur..."
    is BtLinkState.Connected -> "Lidhur me ${state.deviceName}"
    is BtLinkState.Error -> "Gabim: ${state.message}"
}
