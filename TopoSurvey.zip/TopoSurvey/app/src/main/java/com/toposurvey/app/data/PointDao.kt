package com.toposurvey.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface PointDao {
    @Query("SELECT * FROM points WHERE projectId = :projectId ORDER BY timestampUtc DESC")
    fun observeForProject(projectId: Long): Flow<List<SurveyPointEntity>>

    @Insert
    suspend fun insert(point: SurveyPointEntity): Long

    @Delete
    suspend fun delete(point: SurveyPointEntity)

    @Query("SELECT * FROM points WHERE projectId = :projectId ORDER BY timestampUtc DESC")
    suspend fun getForProjectOnce(projectId: Long): List<SurveyPointEntity>
}
