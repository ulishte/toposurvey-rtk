package com.toposurvey.app.gnss

import android.util.Base64
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedOutputStream
import java.io.InputStream
import java.net.Socket

data class NtripSettings(
    val host: String,
    val port: Int = 2101,
    val mountpoint: String,
    val username: String = "",
    val password: String = "",
    /** Send this NMEA GGA line every ~10s so VRS casters can compute a virtual station near the rover. */
    val ggaIntervalMs: Long = 10_000
)

sealed class NtripState {
    data object Disconnected : NtripState()
    data object Connecting : NtripState()
    data object Streaming : NtripState()
    data class Error(val message: String) : NtripState()
}

/**
 * Bare-bones NTRIP v1/v2 client (works against any standard NTRIP caster - CORS
 * networks, or the network operated by the receiver's own vendor). RTCM bytes
 * received from the caster are handed to [onRtcmChunk] so the caller can push
 * them straight to the rover over the Bluetooth link.
 *
 * This intentionally avoids any vendor-proprietary correction SDK: NTRIP is an
 * open standard (RTCM over HTTP) supported by essentially every RTK receiver,
 * so it is the correct integration point for an app we own end to end.
 */
class NtripClient(private val scope: CoroutineScope) {

    private val _state = MutableStateFlow<NtripState>(NtripState.Disconnected)
    val state: StateFlow<NtripState> = _state

    private var job: Job? = null
    private var socket: Socket? = null

    /** Latest GGA sentence to resend to the caster; update this from the live GnssFix. */
    @Volatile var latestGga: String? = null

    fun connect(settings: NtripSettings, onRtcmChunk: (ByteArray) -> Unit) {
        disconnect()
        job = scope.launch(Dispatchers.IO) {
            try {
                _state.value = NtripState.Connecting
                val sock = Socket(settings.host, settings.port)
                socket = sock
                val out = BufferedOutputStream(sock.getOutputStream())
                val request = buildString {
                    append("GET /${settings.mountpoint} HTTP/1.1\r\n")
                    append("Host: ${settings.host}\r\n")
                    append("Ntrip-Version: Ntrip/2.0\r\n")
                    append("User-Agent: NTRIP TopoSurvey/0.1\r\n")
                    if (settings.username.isNotEmpty()) {
                        val cred = Base64.encodeToString(
                            "${settings.username}:${settings.password}".toByteArray(),
                            Base64.NO_WRAP
                        )
                        append("Authorization: Basic $cred\r\n")
                    }
                    append("Connection: close\r\n\r\n")
                }
                out.write(request.toByteArray())
                out.flush()

                val input = sock.getInputStream()
                if (!consumeHttpHeaderAndCheckOk(input)) {
                    _state.value = NtripState.Error("Caster refused connection (check mountpoint/credentials)")
                    return@launch
                }

                _state.value = NtripState.Streaming

                // Periodically resend GGA so VRS-style casters keep the correction near the rover.
                val ggaJob = launch {
                    while (isActive) {
                        latestGga?.let { gga ->
                            runCatching { out.write("$gga\r\n".toByteArray()); out.flush() }
                        }
                        kotlinx.coroutines.delay(settings.ggaIntervalMs)
                    }
                }

                val buffer = ByteArray(4096)
                while (isActive) {
                    val read = input.read(buffer)
                    if (read <= 0) break
                    onRtcmChunk(buffer.copyOf(read))
                }
                ggaJob.cancel()
                _state.value = NtripState.Disconnected
            } catch (t: Throwable) {
                _state.value = NtripState.Error(t.message ?: "NTRIP connection failed")
            } finally {
                runCatching { socket?.close() }
            }
        }
    }

    /** Reads the HTTP/ICY response line + headers, returns true if the caster accepted the request. */
    private fun consumeHttpHeaderAndCheckOk(input: InputStream): Boolean {
        val statusLine = StringBuilder()
        var prev = -1
        while (true) {
            val b = input.read()
            if (b == -1) return false
            statusLine.append(b.toChar())
            if (prev == '\r'.code && b == '\n'.code) break
            prev = b
        }
        val ok = statusLine.contains("200") || statusLine.contains("ICY 200")
        if (!ok) return false
        // Drain remaining headers until blank line.
        var lastFour = IntArray(4) { -1 }
        while (true) {
            val b = input.read()
            if (b == -1) return false
            lastFour = intArrayOf(lastFour[1], lastFour[2], lastFour[3], b)
            if (lastFour[0] == '\r'.code && lastFour[1] == '\n'.code && lastFour[2] == '\r'.code && lastFour[3] == '\n'.code) {
                return true
            }
            // Some casters (ICY) only send \n\n
            if (lastFour[2] == '\n'.code && lastFour[3] == '\n'.code) return true
        }
    }

    fun disconnect() {
        job?.cancel()
        job = null
        runCatching { socket?.close() }
        socket = null
        _state.value = NtripState.Disconnected
    }
}
