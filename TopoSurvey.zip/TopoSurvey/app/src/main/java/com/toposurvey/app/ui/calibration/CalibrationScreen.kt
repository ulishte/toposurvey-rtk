package com.toposurvey.app.ui.calibration

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController

/**
 * Site calibration: stand on a mark whose local coordinates are known, type
 * them in, and the app fits scale, rotation and shifts across all such pairs.
 */
@Composable
fun CalibrationScreen(navController: NavHostController, viewModel: CalibrationViewModel = viewModel()) {
    val points by viewModel.controlPoints.collectAsState()
    val report by viewModel.report.collectAsState()
    val message by viewModel.message.collectAsState()
    val applied by viewModel.applied.collectAsState()

    var label by remember { mutableStateOf("") }
    var knownN by remember { mutableStateOf("") }
    var knownE by remember { mutableStateOf("") }
    var knownH by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Kalibrimi Vendor", style = MaterialTheme.typography.headlineSmall)
        Text(
            if (applied) "Statusi: kalibrimi është AKTIV" else "Statusi: pa kalibrim (rrjeti kombëtar)",
            style = MaterialTheme.typography.bodyMedium
        )
        Text(
            "Qëndro mbi një pikë me koordinata të njohura, shkruaji ato dhe shto pikën. " +
                "Me 1 pikë llogaritet vetëm zhvendosja; me 2+ pika edhe shkalla e rrotullimi.",
            style = MaterialTheme.typography.bodySmall
        )

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Shto pikë kontrolli", style = MaterialTheme.typography.titleSmall)
                OutlinedTextField(
                    value = label, onValueChange = { label = it },
                    label = { Text("Emërtimi") }, modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = knownN, onValueChange = { knownN = it },
                        label = { Text("N e njohur") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = knownE, onValueChange = { knownE = it },
                        label = { Text("E e njohur") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f)
                    )
                }
                OutlinedTextField(
                    value = knownH, onValueChange = { knownH = it },
                    label = { Text("H e njohur (opsionale)") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        viewModel.addFromCurrentPosition(label, knownN, knownE, knownH)
                        label = ""; knownN = ""; knownE = ""; knownH = ""
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Shto nga pozicioni aktual") }
            }
        }

        report?.let { r ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Rezultati i llogaritjes", style = MaterialTheme.typography.titleSmall)
                    Text("Pika të përdorura: ${r.usedPoints}")
                    Text("Shkalla: ${"%.9f".format(r.scale)}")
                    Text("Rrotullimi: ${"%.6f".format(r.rotationDegrees)}°")
                    Text("Zhvendosja vertikale: ${"%.3f".format(r.verticalShift)} m")
                    Text("Residuali maks: ${"%.3f".format(r.maxResidual)} m  ·  RMS: ${"%.3f".format(r.rmsResidual)} m")
                    if (r.usedPoints < 2) {
                        Text(
                            "Me një pikë të vetme residualet janë zero sepse s'ka tepricë - " +
                                "shto të paktën 2-3 pika për kontroll të vërtetë.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    r.residuals.forEach { (name, value) ->
                        Text("  $name: ${"%.3f".format(value)} m", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }

            Button(onClick = { viewModel.applyCalibration() }, modifier = Modifier.fillMaxWidth()) {
                Text("Apliko kalibrimin")
            }
        }

        if (applied) {
            OutlinedButton(onClick = { viewModel.clearCalibration() }, modifier = Modifier.fillMaxWidth()) {
                Text("Hiq kalibrimin")
            }
        }

        message?.let {
            Text(it, style = MaterialTheme.typography.bodySmall)
        }

        Text("Pikat e kontrollit (${points.size})", style = MaterialTheme.typography.titleSmall)
        points.forEach { p ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                    Text("${p.label}${if (!p.enabled) "  (e çaktivizuar)" else ""}", style = MaterialTheme.typography.titleSmall)
                    Text("Matur:  N ${"%.3f".format(p.measuredNorthing)}  E ${"%.3f".format(p.measuredEasting)}", style = MaterialTheme.typography.bodySmall)
                    Text("Njohur: N ${"%.3f".format(p.knownNorthing)}  E ${"%.3f".format(p.knownEasting)}", style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { viewModel.toggleEnabled(p) }) {
                            Text(if (p.enabled) "Çaktivizo" else "Aktivizo")
                        }
                        OutlinedButton(onClick = { viewModel.delete(p) }) { Text("Fshi") }
                    }
                }
            }
        }
    }
}
