package com.toposurvey.app.geo

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

/** Earth-centred, earth-fixed cartesian coordinates in metres. */
data class Ecef(val x: Double, val y: Double, val z: Double)

/**
 * Seven-parameter Helmert (Bursa-Wolf) datum transformation, position-vector
 * convention. Translations in metres, rotations in arc-seconds, scale in ppm.
 *
 * This is what converts a WGS84/ETRS89 GNSS position into a legacy national
 * datum (or back). Leave everything at zero when the project datum is already
 * WGS84/ETRS89 - which is the case for Albania's KRGJSH-2010.
 */
data class DatumTransform(
    val dx: Double = 0.0,
    val dy: Double = 0.0,
    val dz: Double = 0.0,
    val rxArcSec: Double = 0.0,
    val ryArcSec: Double = 0.0,
    val rzArcSec: Double = 0.0,
    val scalePpm: Double = 0.0
) {
    val isIdentity: Boolean
        get() = dx == 0.0 && dy == 0.0 && dz == 0.0 &&
            rxArcSec == 0.0 && ryArcSec == 0.0 && rzArcSec == 0.0 && scalePpm == 0.0

    fun apply(p: Ecef): Ecef {
        if (isIdentity) return p
        val rx = Math.toRadians(rxArcSec / 3600.0)
        val ry = Math.toRadians(ryArcSec / 3600.0)
        val rz = Math.toRadians(rzArcSec / 3600.0)
        val s = 1.0 + scalePpm * 1e-6
        return Ecef(
            x = dx + s * (p.x - rz * p.y + ry * p.z),
            y = dy + s * (rz * p.x + p.y - rx * p.z),
            z = dz + s * (-ry * p.x + rx * p.y + p.z)
        )
    }

    /** Approximate inverse (exact for the small rotations used in practice). */
    fun inverse(): DatumTransform = DatumTransform(-dx, -dy, -dz, -rxArcSec, -ryArcSec, -rzArcSec, -scalePpm)
}

object Geodesy {

    fun geodeticToEcef(ell: Ellipsoid, lat: Double, lon: Double, height: Double): Ecef {
        val phi = Math.toRadians(lat)
        val lam = Math.toRadians(lon)
        val sinPhi = sin(phi)
        val n = ell.a / sqrt(1.0 - ell.e2 * sinPhi * sinPhi)
        return Ecef(
            x = (n + height) * cos(phi) * cos(lam),
            y = (n + height) * cos(phi) * sin(lam),
            z = (n * (1.0 - ell.e2) + height) * sinPhi
        )
    }

    /** Bowring's closed-form inverse - sub-millimetre for terrestrial heights. */
    fun ecefToGeodetic(ell: Ellipsoid, p: Ecef): Triple<Double, Double, Double> {
        val a = ell.a
        val b = ell.b
        val e2 = ell.e2
        val ep2 = (a * a - b * b) / (b * b)
        val pxy = hypot(p.x, p.y)
        val theta = atan2(p.z * a, pxy * b)
        val lat = atan2(
            p.z + ep2 * b * sin(theta).pow(3),
            pxy - e2 * a * cos(theta).pow(3)
        )
        val lon = atan2(p.y, p.x)
        val n = a / sqrt(1.0 - e2 * sin(lat) * sin(lat))
        val h = pxy / cos(lat) - n
        return Triple(Math.toDegrees(lat), Math.toDegrees(lon), h)
    }
}
