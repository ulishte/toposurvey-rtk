package com.toposurvey.app.geo

import kotlin.math.atan2
import kotlin.math.hypot

/**
 * A control point pair used to fit a site localization: the coordinates the
 * rover measured (grid, from the projection) and the coordinates the point is
 * known to have in the client's local/legacy system.
 */
data class ControlPointPair(
    val label: String,
    val measured: GridXY,
    val measuredHeight: Double,
    val known: GridXY,
    val knownHeight: Double
)

/**
 * Four-parameter horizontal fit (2D similarity: scale, rotation, two shifts)
 * plus a vertical shift. This is the "localization" / "site calibration" every
 * surveyor runs when the job is tied to existing local control rather than to
 * the raw national grid.
 *
 *   E' = a·E - b·N + tx
 *   N' = b·E + a·N + ty
 * where a = s·cos(θ), b = s·sin(θ).
 */
data class Localization(
    val a: Double = 1.0,
    val b: Double = 0.0,
    val tx: Double = 0.0,
    val ty: Double = 0.0,
    val verticalShift: Double = 0.0
) {
    val scale: Double get() = hypot(a, b)
    val rotationDegrees: Double get() = Math.toDegrees(atan2(b, a))

    val isIdentity: Boolean
        get() = a == 1.0 && b == 0.0 && tx == 0.0 && ty == 0.0 && verticalShift == 0.0

    fun apply(p: GridXY): GridXY =
        if (isIdentity) p
        else GridXY(a * p.easting - b * p.northing + tx, b * p.easting + a * p.northing + ty)

    fun applyHeight(h: Double): Double = h + verticalShift

    /** Undo the horizontal fit (used when staking a known local coordinate). */
    fun invert(p: GridXY): GridXY {
        if (isIdentity) return p
        val det = a * a + b * b
        if (det == 0.0) return p
        val x = p.easting - tx
        val y = p.northing - ty
        return GridXY((a * x + b * y) / det, (-b * x + a * y) / det)
    }

    companion object {
        /**
         * Least-squares fit over [pairs]. One pair gives a pure shift, two or
         * more give the full similarity. Returns null if there is no usable data.
         */
        fun fit(pairs: List<ControlPointPair>): Localization? {
            if (pairs.isEmpty()) return null

            val verticalShift = pairs.map { it.knownHeight - it.measuredHeight }.average()

            if (pairs.size == 1) {
                val p = pairs.first()
                return Localization(
                    a = 1.0,
                    b = 0.0,
                    tx = p.known.easting - p.measured.easting,
                    ty = p.known.northing - p.measured.northing,
                    verticalShift = verticalShift
                )
            }

            val n = pairs.size
            val smE = pairs.sumOf { it.measured.easting } / n
            val smN = pairs.sumOf { it.measured.northing } / n
            val skE = pairs.sumOf { it.known.easting } / n
            val skN = pairs.sumOf { it.known.northing } / n

            var numA = 0.0
            var numB = 0.0
            var den = 0.0
            for (p in pairs) {
                val x = p.measured.easting - smE
                val y = p.measured.northing - smN
                val u = p.known.easting - skE
                val v = p.known.northing - skN
                numA += x * u + y * v
                numB += x * v - y * u
                den += x * x + y * y
            }
            if (den == 0.0) return null

            val a = numA / den
            val b = numB / den
            val tx = skE - (a * smE - b * smN)
            val ty = skN - (b * smE + a * smN)
            return Localization(a, b, tx, ty, verticalShift)
        }

        /** Per-point horizontal residuals after applying [loc] - the quality check. */
        fun residuals(loc: Localization, pairs: List<ControlPointPair>): List<Double> =
            pairs.map { p ->
                val fitted = loc.apply(p.measured)
                hypot(fitted.easting - p.known.easting, fitted.northing - p.known.northing)
            }
    }
}
