package com.toposurvey.app.export

import java.io.InputStream

/** A design point read from an office CSV, ready to be staked out. */
data class ImportedPoint(
    val code: String,
    val northing: Double,
    val easting: Double,
    val height: Double?
)

/**
 * Reads the classic surveying exchange format produced by every office
 * package: `code, northing, easting, height, description` - one point per
 * line, comma or semicolon separated, header optional.
 */
object PointCsvImporter {

    fun parse(stream: InputStream): List<ImportedPoint> {
        val result = mutableListOf<ImportedPoint>()
        stream.bufferedReader().forEachLine { raw ->
            val line = raw.trim()
            if (line.isEmpty() || line.startsWith("#")) return@forEachLine

            val parts = line.split(';', ',', '\t').map { it.trim() }
            if (parts.size < 3) return@forEachLine

            val n = parts[1].replace(",", ".").toDoubleOrNull()
            val e = parts[2].replace(",", ".").toDoubleOrNull()
            // A header row simply fails to parse as numbers and is skipped.
            if (n == null || e == null) return@forEachLine

            val h = parts.getOrNull(3)?.replace(",", ".")?.toDoubleOrNull()
            result.add(ImportedPoint(code = parts[0].ifBlank { "PT" }, northing = n, easting = e, height = h))
        }
        return result
    }
}
