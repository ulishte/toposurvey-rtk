package com.toposurvey.app.geo

import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Parameters of a Transverse Mercator projection (the projection behind UTM,
 * Gauss-Krüger, and most national grids including Albania's KRGJSH-2010).
 *
 * Angles are in degrees, distances in metres.
 */
data class TmParameters(
    /** Latitude of origin. */
    val latitudeOfOrigin: Double,
    /** Central meridian. */
    val centralMeridian: Double,
    /** Scale factor at the central meridian. */
    val scaleFactor: Double,
    val falseEasting: Double,
    val falseNorthing: Double
)

/** Planar grid coordinates: easting/northing in metres. */
data class GridXY(val easting: Double, val northing: Double)

/** Geodetic position in degrees, height in metres above the ellipsoid. */
data class LatLon(val latitude: Double, val longitude: Double)

/**
 * Transverse Mercator projection using the classic Snyder/USGS series.
 *
 * Verified against Snyder, "Map Projections - A Working Manual", worked example
 * (Clarke 1866, k0=0.9996, CM 75°W, point 40°30'N 73°30'W -> x=127106.5,
 * y=4484124.4) and round-trips to well under a millimetre across a national
 * grid zone, which is far below GNSS noise.
 */
object TransverseMercator {

    private fun meridionalArc(ell: Ellipsoid, phi: Double): Double {
        val e2 = ell.e2
        val e4 = e2 * e2
        val e6 = e4 * e2
        return ell.a * (
            (1.0 - e2 / 4.0 - 3.0 * e4 / 64.0 - 5.0 * e6 / 256.0) * phi -
                (3.0 * e2 / 8.0 + 3.0 * e4 / 32.0 + 45.0 * e6 / 1024.0) * sin(2.0 * phi) +
                (15.0 * e4 / 256.0 + 45.0 * e6 / 1024.0) * sin(4.0 * phi) -
                (35.0 * e6 / 3072.0) * sin(6.0 * phi)
            )
    }

    fun forward(ell: Ellipsoid, p: TmParameters, position: LatLon): GridXY {
        val e2 = ell.e2
        val ep2 = ell.ep2
        val phi = Math.toRadians(position.latitude)
        val lam = Math.toRadians(position.longitude)
        val phi0 = Math.toRadians(p.latitudeOfOrigin)
        val lam0 = Math.toRadians(p.centralMeridian)
        val k0 = p.scaleFactor

        val sinPhi = sin(phi)
        val cosPhi = cos(phi)
        val tanPhi = tan(phi)

        val n = ell.a / sqrt(1.0 - e2 * sinPhi * sinPhi)
        val t = tanPhi * tanPhi
        val c = ep2 * cosPhi * cosPhi
        val aTerm = (lam - lam0) * cosPhi

        val m = meridionalArc(ell, phi)
        val m0 = meridionalArc(ell, phi0)

        val easting = p.falseEasting + k0 * n * (
            aTerm +
                (1.0 - t + c) * aTerm.pow(3) / 6.0 +
                (5.0 - 18.0 * t + t * t + 72.0 * c - 58.0 * ep2) * aTerm.pow(5) / 120.0
            )

        val northing = p.falseNorthing + k0 * (
            m - m0 + n * tanPhi * (
                aTerm * aTerm / 2.0 +
                    (5.0 - t + 9.0 * c + 4.0 * c * c) * aTerm.pow(4) / 24.0 +
                    (61.0 - 58.0 * t + t * t + 600.0 * c - 330.0 * ep2) * aTerm.pow(6) / 720.0
                )
            )

        return GridXY(easting, northing)
    }

    fun inverse(ell: Ellipsoid, p: TmParameters, grid: GridXY): LatLon {
        val e2 = ell.e2
        val ep2 = ell.ep2
        val phi0 = Math.toRadians(p.latitudeOfOrigin)
        val lam0 = Math.toRadians(p.centralMeridian)
        val k0 = p.scaleFactor

        val m0 = meridionalArc(ell, phi0)
        val m = m0 + (grid.northing - p.falseNorthing) / k0

        val e4 = e2 * e2
        val e6 = e4 * e2
        val mu = m / (ell.a * (1.0 - e2 / 4.0 - 3.0 * e4 / 64.0 - 5.0 * e6 / 256.0))

        val e1 = (1.0 - sqrt(1.0 - e2)) / (1.0 + sqrt(1.0 - e2))
        val phi1 = mu +
            (3.0 * e1 / 2.0 - 27.0 * e1.pow(3) / 32.0) * sin(2.0 * mu) +
            (21.0 * e1 * e1 / 16.0 - 55.0 * e1.pow(4) / 32.0) * sin(4.0 * mu) +
            (151.0 * e1.pow(3) / 96.0) * sin(6.0 * mu) +
            (1097.0 * e1.pow(4) / 512.0) * sin(8.0 * mu)

        val sinPhi1 = sin(phi1)
        val cosPhi1 = cos(phi1)
        val tanPhi1 = tan(phi1)

        val c1 = ep2 * cosPhi1 * cosPhi1
        val t1 = tanPhi1 * tanPhi1
        val n1 = ell.a / sqrt(1.0 - e2 * sinPhi1 * sinPhi1)
        val r1 = ell.a * (1.0 - e2) / (1.0 - e2 * sinPhi1 * sinPhi1).pow(1.5)
        val d = (grid.easting - p.falseEasting) / (n1 * k0)

        val phi = phi1 - (n1 * tanPhi1 / r1) * (
            d * d / 2.0 -
                (5.0 + 3.0 * t1 + 10.0 * c1 - 4.0 * c1 * c1 - 9.0 * ep2) * d.pow(4) / 24.0 +
                (61.0 + 90.0 * t1 + 298.0 * c1 + 45.0 * t1 * t1 - 252.0 * ep2 - 3.0 * c1 * c1) * d.pow(6) / 720.0
            )

        val lam = lam0 + (
            d -
                (1.0 + 2.0 * t1 + c1) * d.pow(3) / 6.0 +
                (5.0 - 2.0 * c1 + 28.0 * t1 - 3.0 * c1 * c1 + 8.0 * ep2 + 24.0 * t1 * t1) * d.pow(5) / 120.0
            ) / cosPhi1

        return LatLon(Math.toDegrees(phi), Math.toDegrees(lam))
    }

    /**
     * Grid convergence (angle between grid north and true north) in degrees.
     * Surveyors need this to relate a grid bearing to an astronomic/true bearing.
     */
    fun convergence(ell: Ellipsoid, p: TmParameters, position: LatLon): Double {
        val phi = Math.toRadians(position.latitude)
        val dLam = Math.toRadians(position.longitude - p.centralMeridian)
        val ep2 = ell.ep2
        val cosPhi = cos(phi)
        val c = ep2 * cosPhi * cosPhi
        val gamma = dLam * sin(phi) *
            (1.0 + (dLam * dLam / 3.0) * cosPhi * cosPhi * (1.0 + 3.0 * c + 2.0 * c * c))
        return Math.toDegrees(gamma)
    }

    /** Point scale factor at a position (how much the grid stretches distances there). */
    fun pointScaleFactor(ell: Ellipsoid, p: TmParameters, position: LatLon): Double {
        val phi = Math.toRadians(position.latitude)
        val dLam = Math.toRadians(position.longitude - p.centralMeridian)
        val cosPhi = cos(phi)
        val t = tan(phi) * tan(phi)
        val c = ell.ep2 * cosPhi * cosPhi
        val a2 = (dLam * cosPhi) * (dLam * cosPhi)
        return p.scaleFactor * (1.0 + a2 / 2.0 * (1.0 + c) + a2 * a2 / 24.0 * (5.0 - 4.0 * t))
    }
}
