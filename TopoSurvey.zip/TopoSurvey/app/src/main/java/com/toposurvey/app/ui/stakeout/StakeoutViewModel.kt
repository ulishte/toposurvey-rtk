package com.toposurvey.app.ui.stakeout

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.toposurvey.app.SurveyEngine
import com.toposurvey.app.TopoSurveyApp
import com.toposurvey.app.data.SurveyPointEntity
import com.toposurvey.app.gnss.GnssFix
import com.toposurvey.app.util.GeoMath
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn

data class StakeoutGuidance(val distanceMeters: Double, val bearingDegrees: Double)

class StakeoutViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as TopoSurveyApp).repository
    private val projectId = SurveyEngine.activeProjectId

    val points: StateFlow<List<SurveyPointEntity>> =
        (if (projectId != null) repository.observePoints(projectId) else flowOf(emptyList()))
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val currentFix: StateFlow<GnssFix?> = SurveyEngine.currentFix

    private val _target = MutableStateFlow<SurveyPointEntity?>(null)
    val target: StateFlow<SurveyPointEntity?> = _target

    fun selectTarget(point: SurveyPointEntity) {
        _target.value = point
    }

    fun guidance(fix: GnssFix, target: SurveyPointEntity): StakeoutGuidance = StakeoutGuidance(
        distanceMeters = GeoMath.distanceMeters(fix.latitude, fix.longitude, target.latitude, target.longitude),
        bearingDegrees = GeoMath.bearingDegrees(fix.latitude, fix.longitude, target.latitude, target.longitude)
    )
}
