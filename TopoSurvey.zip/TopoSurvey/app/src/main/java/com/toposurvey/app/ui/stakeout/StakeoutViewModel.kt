package com.toposurvey.app.ui.stakeout

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.toposurvey.app.SurveyEngine
import com.toposurvey.app.TopoSurveyApp
import com.toposurvey.app.data.SurveyPointEntity
import com.toposurvey.app.geo.CoordinateSystem
import com.toposurvey.app.geo.GridResult
import com.toposurvey.app.util.GeoMath
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn
import kotlin.math.atan2
import kotlin.math.hypot

/** A stakeout target expressed in grid coordinates. */
data class StakeTarget(
    val label: String,
    val northing: Double,
    val easting: Double,
    val height: Double?
)

/**
 * Live guidance to the target. Deltas are given both as grid components
 * (what a surveyor reads off a design drawing) and as distance/bearing.
 */
data class StakeoutGuidance(
    val deltaNorth: Double,
    val deltaEast: Double,
    val distance: Double,
    val gridBearingDegrees: Double,
    val deltaHeight: Double?
)

class StakeoutViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as TopoSurveyApp).repository
    private val projectId = SurveyEngine.activeProjectId

    val coordinateSystem: StateFlow<CoordinateSystem> = SurveyEngine.coordinateSystem
    val currentGrid: StateFlow<GridResult?> = SurveyEngine.currentGrid

    val points: StateFlow<List<SurveyPointEntity>> =
        (if (projectId != null) repository.observePoints(projectId) else flowOf(emptyList()))
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _target = MutableStateFlow<StakeTarget?>(null)
    val target: StateFlow<StakeTarget?> = _target

    fun selectFromLibrary(point: SurveyPointEntity) {
        val g = coordinateSystem.value.fromWgs84(point.latitude, point.longitude, point.ellipsoidalHeight)
        _target.value = if (g != null) {
            StakeTarget(point.code, g.northing, g.easting, g.height)
        } else {
            // Geographic-only system: fall back to storing the raw values.
            StakeTarget(point.code, point.latitude, point.longitude, point.ellipsoidalHeight)
        }
    }

    /** Manually entered design coordinate (the normal stakeout workflow). */
    fun setManualTarget(label: String, northing: Double, easting: Double, height: Double?) {
        _target.value = StakeTarget(label.ifBlank { "Objektiv" }, northing, easting, height)
    }

    fun clearTarget() {
        _target.value = null
    }

    fun guidance(current: GridResult, target: StakeTarget): StakeoutGuidance {
        val dN = target.northing - current.northing
        val dE = target.easting - current.easting
        val bearing = (Math.toDegrees(atan2(dE, dN)) + 360.0) % 360.0
        return StakeoutGuidance(
            deltaNorth = dN,
            deltaEast = dE,
            distance = hypot(dN, dE),
            gridBearingDegrees = bearing,
            deltaHeight = target.height?.let { it - current.height }
        )
    }

    /** Fallback used when the project has no projection (pure lat/lon mode). */
    fun geographicGuidance(
        latitude: Double,
        longitude: Double,
        target: StakeTarget
    ): StakeoutGuidance {
        val distance = GeoMath.distanceMeters(latitude, longitude, target.northing, target.easting)
        val bearing = GeoMath.bearingDegrees(latitude, longitude, target.northing, target.easting)
        return StakeoutGuidance(
            deltaNorth = 0.0,
            deltaEast = 0.0,
            distance = distance,
            gridBearingDegrees = bearing,
            deltaHeight = null
        )
    }
}
