package com.toposurvey.app.ui.library

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController

@Composable
fun PointsLibraryScreen(navController: NavHostController, viewModel: PointsLibraryViewModel = viewModel()) {
    val points by viewModel.points.collectAsState()
    val exported by viewModel.lastExportedFile.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Libraria e Pikave", style = MaterialTheme.typography.headlineSmall)
        Text("${points.size} pikë të regjistruara")

        Button(onClick = { viewModel.exportCsv() }, modifier = Modifier.fillMaxWidth()) {
            Text("Eksporto CSV")
        }
        exported?.let { Text("U ruajt: ${it.absolutePath}") }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(points) { p ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${p.code} - ${p.description}", style = MaterialTheme.typography.titleSmall)
                        Text("Lat ${"%.7f".format(p.latitude)}  Lon ${"%.7f".format(p.longitude)}  H ${"%.3f".format(p.ellipsoidalHeight)}")
                        Text("Fiks ${p.fixQuality} · HDOP ${p.hdop} · Sat ${p.satellites}", style = MaterialTheme.typography.bodySmall)
                        Button(onClick = { viewModel.deletePoint(p) }) { Text("Fshi") }
                    }
                }
            }
        }
    }
}
