package com.toposurvey.app.ui.library

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController

@Composable
fun PointsLibraryScreen(navController: NavHostController, viewModel: PointsLibraryViewModel = viewModel()) {
    val points by viewModel.points.collectAsState()
    val exported by viewModel.lastExportedFile.collectAsState()
    val cs by viewModel.coordinateSystem.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Libraria e Pikave", style = MaterialTheme.typography.headlineSmall)
        Text("${points.size} pikë · ${cs.name}", style = MaterialTheme.typography.bodySmall)

        Button(onClick = { viewModel.exportCsv() }, modifier = Modifier.fillMaxWidth()) {
            Text("Eksporto CSV")
        }
        exported?.let { Text("U ruajt: ${it.absolutePath}", style = MaterialTheme.typography.bodySmall) }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(points) { p ->
                val g = viewModel.gridFor(p)
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("${p.code} - ${p.description}", style = MaterialTheme.typography.titleSmall)
                        if (g != null) {
                            Text("N ${"%.3f".format(g.northing)}  E ${"%.3f".format(g.easting)}  H ${"%.3f".format(g.height)}")
                        }
                        Text(
                            "WGS84 ${"%.7f".format(p.latitude)}, ${"%.7f".format(p.longitude)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text("Fiks ${p.fixQuality} · HDOP ${p.hdop} · Sat ${p.satellites}", style = MaterialTheme.typography.bodySmall)
                        OutlinedButton(onClick = { viewModel.deletePoint(p) }) { Text("Fshi") }
                    }
                }
            }
        }
    }
}
