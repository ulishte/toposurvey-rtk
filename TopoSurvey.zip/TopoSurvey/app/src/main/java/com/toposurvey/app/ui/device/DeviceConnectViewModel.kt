package com.toposurvey.app.ui.device

import android.app.Application
import android.bluetooth.BluetoothDevice
import androidx.lifecycle.AndroidViewModel
import com.toposurvey.app.SurveyEngine
import com.toposurvey.app.bluetooth.BtLinkState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

enum class LinkMode { SPP, BLE }

class DeviceConnectViewModel(application: Application) : AndroidViewModel(application) {
    val linkState: StateFlow<BtLinkState> = SurveyEngine.linkState

    private val _mode = MutableStateFlow(LinkMode.SPP)
    val mode: StateFlow<LinkMode> = _mode

    fun setMode(mode: LinkMode) {
        _mode.value = mode
    }

    fun pairedDevices(): List<BluetoothDevice> =
        if (_mode.value == LinkMode.SPP) SurveyEngine.bluetooth.pairedDevices(getApplication())
        else SurveyEngine.ble.bondedDevices(getApplication())

    fun connect(device: BluetoothDevice) {
        SurveyEngine.disconnectAll()
        if (_mode.value == LinkMode.SPP) {
            SurveyEngine.bluetooth.connect(device)
        } else {
            SurveyEngine.ble.connect(getApplication(), device)
        }
    }

    fun disconnect() = SurveyEngine.disconnectAll()
}
