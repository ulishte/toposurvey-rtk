package com.toposurvey.app.ui.device

import android.app.Application
import android.bluetooth.BluetoothDevice
import androidx.lifecycle.AndroidViewModel
import com.toposurvey.app.SurveyEngine
import com.toposurvey.app.bluetooth.BtLinkState
import kotlinx.coroutines.flow.StateFlow

class DeviceConnectViewModel(application: Application) : AndroidViewModel(application) {
    val linkState: StateFlow<BtLinkState> = SurveyEngine.bluetooth.state

    fun pairedDevices(): List<BluetoothDevice> = SurveyEngine.bluetooth.pairedDevices(getApplication())

    fun connect(device: BluetoothDevice) = SurveyEngine.bluetooth.connect(device)

    fun disconnect() = SurveyEngine.bluetooth.disconnect()
}
