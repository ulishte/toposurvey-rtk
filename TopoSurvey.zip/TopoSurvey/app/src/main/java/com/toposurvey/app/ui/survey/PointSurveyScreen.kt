package com.toposurvey.app.ui.survey

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.toposurvey.app.gnss.FixQuality

@Composable
fun PointSurveyScreen(navController: NavHostController, viewModel: PointSurveyViewModel = viewModel()) {
    val fix by viewModel.currentFix.collectAsState()
    val grid by viewModel.currentGrid.collectAsState()
    val cs by viewModel.coordinateSystem.collectAsState()
    val antenna by viewModel.antennaHeight.collectAsState()
    val capture by viewModel.capture.collectAsState()
    val suggested by viewModel.suggestedCode.collectAsState()

    var code by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var antennaText by remember { mutableStateOf(if (antenna == 0.0) "" else antenna.toString()) }
    var epochsText by remember { mutableStateOf("5") }

    LaunchedEffect(suggested) { if (code.isBlank()) code = suggested }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Rilevim Pikash", style = MaterialTheme.typography.headlineSmall)
        Text(cs.name, style = MaterialTheme.typography.bodySmall)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                val f = fix
                if (f == null) {
                    Text("Ende pa pozicion - kontrollo lidhjen me rover-in.")
                } else {
                    val g = grid
                    if (g != null) {
                        Text("N  ${"%.3f".format(g.northing)} m", style = MaterialTheme.typography.titleMedium)
                        Text("E  ${"%.3f".format(g.easting)} m", style = MaterialTheme.typography.titleMedium)
                        Text("H  ${"%.3f".format(g.height)} m  (marka në tokë)", style = MaterialTheme.typography.titleMedium)
                        Text(
                            "Konvergjenca ${"%.4f".format(g.convergenceDegrees)}°  ·  " +
                                "Fakt. shkalle ${"%.7f".format(g.scaleFactor)}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    Text(
                        "WGS84 ${"%.8f".format(f.latitude)}, ${"%.8f".format(f.longitude)}  " +
                            "h antene ${"%.3f".format(f.ellipsoidalHeight)}",
                        style = MaterialTheme.typography.bodySmall
                    )
                    Text(fixLabel(f.fixQuality) + " · Satelitë ${f.satellites} · HDOP ${f.hdop}")
                    if (f.fixQuality != FixQuality.RTK_FIXED) {
                        Text(
                            "⚠ Pa zgjidhje RTK Fixed saktësia është dhjetëra cm ose më keq.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(
                value = antennaText,
                onValueChange = { antennaText = it; viewModel.setAntennaHeight(it) },
                label = { Text("Lartësia e shkopit (m)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.weight(1f)
            )
            OutlinedTextField(
                value = epochsText,
                onValueChange = { epochsText = it },
                label = { Text("Epoka") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.weight(1f)
            )
        }

        OutlinedTextField(
            value = code,
            onValueChange = { code = it },
            label = { Text("Kodi i pikës") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = description,
            onValueChange = { description = it },
            label = { Text("Përshkrimi") },
            modifier = Modifier.fillMaxWidth()
        )

        val collecting = capture is CaptureState.Collecting
        Button(
            onClick = {
                viewModel.collectPoint(code, description, epochsText.toIntOrNull() ?: 5)
                description = ""
            },
            enabled = !collecting,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (collecting) "Duke matur..." else "Regjistro Pikën")
        }

        when (val c = capture) {
            is CaptureState.Saved -> {
                Text(c.summary, style = MaterialTheme.typography.bodySmall)
                LaunchedEffect(c) { code = "" }
            }
            is CaptureState.Failed -> Text(c.reason, style = MaterialTheme.typography.bodySmall)
            is CaptureState.Collecting -> Text("Duke mbledhur epoka...", style = MaterialTheme.typography.bodySmall)
            CaptureState.Idle -> {}
        }
    }
}

private fun fixLabel(q: FixQuality): String = when (q) {
    FixQuality.RTK_FIXED -> "RTK Fixed (cm)"
    FixQuality.RTK_FLOAT -> "RTK Float (dm)"
    FixQuality.DGPS -> "DGPS (sub-m)"
    FixQuality.GPS -> "GPS autonom (m)"
    FixQuality.INVALID -> "Pa fiks"
    else -> q.name
}
