package com.toposurvey.app.ui.survey

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController

@Composable
fun PointSurveyScreen(navController: NavHostController, viewModel: PointSurveyViewModel = viewModel()) {
    val fix by viewModel.currentFix.collectAsState()
    var code by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var message by remember { mutableStateOf<String?>(null) }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Rilevim Pikash", style = MaterialTheme.typography.headlineSmall)

        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                if (fix == null) {
                    Text("Ende pa pozicion - kontrollo lidhjen me rover-in.")
                } else {
                    val f = fix!!
                    Text("Gjerësia: ${"%.8f".format(f.latitude)}")
                    Text("Gjatësia: ${"%.8f".format(f.longitude)}")
                    Text("Lartësia elipsoidale: ${"%.3f".format(f.ellipsoidalHeight)} m")
                    Text("Fiksi: ${f.fixQuality} · Satelitë: ${f.satellites} · HDOP: ${f.hdop}")
                }
            }
        }

        OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text("Kodi i pikës") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("Përshkrimi") }, modifier = Modifier.fillMaxWidth())

        Button(
            onClick = {
                viewModel.collectPoint(code, description) { success ->
                    message = if (success) "Pika u ruajt." else "Zgjidh një projekt (nga Home) dhe prit pozicion para se të regjistrosh."
                    if (success) { code = ""; description = "" }
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Regjistro Pikën")
        }

        message?.let { Text(it) }
    }
}
