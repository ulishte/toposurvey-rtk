package com.toposurvey.app.ui.calc

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.toposurvey.app.SurveyEngine
import com.toposurvey.app.TopoSurveyApp
import com.toposurvey.app.data.SurveyPointEntity
import com.toposurvey.app.geo.AreaResult
import com.toposurvey.app.geo.Cogo
import com.toposurvey.app.geo.GridXY
import com.toposurvey.app.geo.InverseResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.stateIn

class CalcViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = (application as TopoSurveyApp).repository
    private val projectId = SurveyEngine.activeProjectId

    val points: StateFlow<List<SurveyPointEntity>> =
        (if (projectId != null) repository.observePoints(projectId) else flowOf(emptyList()))
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    /** Points chosen for the polygon, in the order the user tapped them. */
    private val _selected = MutableStateFlow<List<SurveyPointEntity>>(emptyList())
    val selected: StateFlow<List<SurveyPointEntity>> = _selected

    private val _areaResult = MutableStateFlow<AreaResult?>(null)
    val areaResult: StateFlow<AreaResult?> = _areaResult

    private val _inverseResult = MutableStateFlow<InverseResult?>(null)
    val inverseResult: StateFlow<InverseResult?> = _inverseResult

    private val _forwardResult = MutableStateFlow<GridXY?>(null)
    val forwardResult: StateFlow<GridXY?> = _forwardResult

    fun toggle(point: SurveyPointEntity) {
        val current = _selected.value
        _selected.value = if (current.any { it.id == point.id }) current.filterNot { it.id == point.id }
        else current + point
        computeArea()
    }

    fun clearSelection() {
        _selected.value = emptyList()
        _areaResult.value = null
    }

    private fun gridOf(p: SurveyPointEntity): GridXY? {
        val g = SurveyEngine.project(p.latitude, p.longitude, p.ellipsoidalHeight) ?: return null
        return GridXY(g.easting, g.northing)
    }

    private fun computeArea() {
        val verts = _selected.value.mapNotNull { gridOf(it) }
        _areaResult.value = Cogo.area(verts)
    }

    fun inverse(n1: String, e1: String, h1: String, n2: String, e2: String, h2: String) {
        val a = parse(n1); val b = parse(e1)
        val c = parse(n2); val d = parse(e2)
        if (a == null || b == null || c == null || d == null) {
            _inverseResult.value = null
            return
        }
        _inverseResult.value = Cogo.inverse(a, b, parse(h1), c, d, parse(h2))
    }

    fun forward(n: String, e: String, bearing: String, distance: String) {
        val a = parse(n); val b = parse(e)
        val br = parse(bearing); val d = parse(distance)
        if (a == null || b == null || br == null || d == null) {
            _forwardResult.value = null
            return
        }
        _forwardResult.value = Cogo.forward(a, b, br, d)
    }

    fun useCurrentPositionAsStart(): Pair<String, String>? {
        val g = SurveyEngine.currentGrid.value ?: return null
        return "%.3f".format(g.northing) to "%.3f".format(g.easting)
    }

    fun dms(degrees: Double): String = Cogo.toDms(degrees)

    private fun parse(s: String): Double? = s.replace(",", ".").toDoubleOrNull()
}
