package com.toposurvey.app.ui.stakeout

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import kotlin.math.abs

/**
 * Stakeout in grid coordinates: pick a stored point or type a design N/E,
 * then walk in until the deltas go to zero.
 */
@Composable
fun StakeoutScreen(navController: NavHostController, viewModel: StakeoutViewModel = viewModel()) {
    val points by viewModel.points.collectAsState()
    val grid by viewModel.currentGrid.collectAsState()
    val target by viewModel.target.collectAsState()
    val cs by viewModel.coordinateSystem.collectAsState()

    val imported by viewModel.imported.collectAsState()
    val importMessage by viewModel.importMessage.collectAsState()

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri -> uri?.let { viewModel.importFrom(it) } }

    var manualN by remember { mutableStateOf("") }
    var manualE by remember { mutableStateOf("") }
    var manualH by remember { mutableStateOf("") }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Skedarizim (Stakeout)", style = MaterialTheme.typography.headlineSmall)
        Text(cs.name, style = MaterialTheme.typography.bodySmall)

        val t = target
        if (t == null) {
            Text("Objektiv i ri (koordinata projekti):", style = MaterialTheme.typography.titleSmall)
            OutlinedTextField(value = manualN, onValueChange = { manualN = it }, label = { Text("Veriu (N)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = manualE, onValueChange = { manualE = it }, label = { Text("Lindja (E)") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = manualH, onValueChange = { manualH = it }, label = { Text("Lartësia (H) - opsionale") }, modifier = Modifier.fillMaxWidth())
            Button(
                onClick = {
                    val n = manualN.replace(",", ".").toDoubleOrNull()
                    val e = manualE.replace(",", ".").toDoubleOrNull()
                    if (n != null && e != null) {
                        viewModel.setManualTarget("Manual", n, e, manualH.replace(",", ".").toDoubleOrNull())
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Vendos objektivin") }

            OutlinedButton(
                onClick = { picker.launch(arrayOf("*/*")) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Importo pika projekti (CSV)") }
            importMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

            if (imported.isNotEmpty()) {
                Text("Pika të importuara (${imported.size}):", style = MaterialTheme.typography.titleSmall)
                imported.forEach { ip ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text(ip.code)
                            Text(
                                "N ${"%.3f".format(ip.northing)}  E ${"%.3f".format(ip.easting)}" +
                                    (ip.height?.let { "  H ${"%.3f".format(it)}" } ?: ""),
                                style = MaterialTheme.typography.bodySmall
                            )
                            Button(onClick = { viewModel.selectImported(ip) }) { Text("Skedarizo") }
                        }
                    }
                }
            }

            Text("Ose zgjidh nga pikat e ruajtura:", style = MaterialTheme.typography.titleSmall)
            points.forEach { p ->
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${p.code} - ${p.description}")
                        Button(onClick = { viewModel.selectFromLibrary(p) }) { Text("Zgjidh") }
                    }
                }
            }
        } else {
            Text("Objektivi: ${t.label}", style = MaterialTheme.typography.titleMedium)
            Text(
                "N ${"%.3f".format(t.northing)}  E ${"%.3f".format(t.easting)}" +
                    (t.height?.let { "  H ${"%.3f".format(it)}" } ?: ""),
                style = MaterialTheme.typography.bodySmall
            )

            val g = grid
            if (g == null) {
                Text("Ende pa pozicion nga rover-i.")
            } else {
                val guide = viewModel.guidance(g, t)
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("Distanca: ${"%.3f".format(guide.distance)} m", style = MaterialTheme.typography.headlineSmall)
                        Text("Azimuti i rrjetit: ${"%.2f".format(guide.gridBearingDegrees)}°")
                        Text(directionHint(guide.deltaNorth, guide.deltaEast), style = MaterialTheme.typography.titleSmall)
                        guide.deltaHeight?.let {
                            val label = if (it > 0) "Ngri (fill)" else "Ul (cut)"
                            Text("$label: ${"%.3f".format(abs(it))} m")
                        }
                    }
                }
            }

            OutlinedButton(onClick = { viewModel.clearTarget() }, modifier = Modifier.fillMaxWidth()) {
                Text("Ndrysho objektivin")
            }
        }
    }
}

private fun directionHint(deltaNorth: Double, deltaEast: Double): String {
    val ns = if (deltaNorth >= 0) "Veri" else "Jug"
    val ew = if (deltaEast >= 0) "Lindje" else "Perëndim"
    return "Lëviz ${"%.3f".format(abs(deltaNorth))} m $ns  dhe  ${"%.3f".format(abs(deltaEast))} m $ew"
}
