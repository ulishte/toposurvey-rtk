package com.toposurvey.app.ui.stakeout

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController

/**
 * Basic stakeout: pick a target point from the library, see live
 * distance + bearing from the rover's current position to it.
 * Phase 2 TODO: replace absolute bearing with a heading-relative arrow
 * once course-over-ground (from RMC) or a device compass is wired in,
 * and add left/right + cut/fill guidance like professional stakeout screens.
 */
@Composable
fun StakeoutScreen(navController: NavHostController, viewModel: StakeoutViewModel = viewModel()) {
    val points by viewModel.points.collectAsState()
    val fix by viewModel.currentFix.collectAsState()
    val target by viewModel.target.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Skedarizim (Stakeout)", style = MaterialTheme.typography.headlineSmall)

        if (target == null) {
            Text("Zgjidh një pikë objektiv:")
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(points) { p ->
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(12.dp)) {
                            Text("${p.code} - ${p.description}")
                            Button(onClick = { viewModel.selectTarget(p) }) { Text("Zgjidh") }
                        }
                    }
                }
            }
        } else {
            val t = target!!
            Text("Objektivi: ${t.code} - ${t.description}", style = MaterialTheme.typography.titleMedium)
            val f = fix
            if (f == null) {
                Text("Ende pa pozicion nga rover-i.")
            } else {
                val g = viewModel.guidance(f, t)
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("Distanca: ${"%.3f".format(g.distanceMeters)} m", style = MaterialTheme.typography.headlineSmall)
                        Text("Azimuti: ${"%.1f".format(g.bearingDegrees)}°")
                    }
                }
            }
            Button(onClick = { viewModel.selectTarget(t) }) { Text("Rifresko") }
        }
    }
}
