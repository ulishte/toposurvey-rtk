package com.toposurvey.app.export

import android.content.Context
import com.toposurvey.app.data.SurveyPointEntity
import com.toposurvey.app.geo.CoordinateSystem
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CsvExporter {

    /**
     * Writes points to <app-external-files>/Export/<projectName>_<timestamp>.csv.
     *
     * Both the projected grid coordinates (what the surveyor works in) and the
     * raw WGS84 values (the permanent record) are exported, so the file is
     * useful in CAD and re-projectable later.
     */
    fun export(
        context: Context,
        projectName: String,
        points: List<SurveyPointEntity>,
        system: CoordinateSystem
    ): File {
        val dir = File(context.getExternalFilesDir(null), "Export").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val safeName = projectName.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val file = File(dir, "${safeName}_$stamp.csv")

        file.bufferedWriter().use { writer ->
            writer.write("# Sistemi: ${system.name}")
            writer.newLine()
            writer.write("Code,Description,Northing,Easting,Height,Latitude,Longitude,EllipsoidalHeight,FixQuality,HDOP,Satellites,TimestampUtc")
            writer.newLine()
            points.forEach { p ->
                val grid = system.fromWgs84(p.latitude, p.longitude, p.ellipsoidalHeight)
                val cells = listOf(
                    p.code,
                    p.description,
                    grid?.northing?.let { "%.4f".format(Locale.US, it) } ?: "",
                    grid?.easting?.let { "%.4f".format(Locale.US, it) } ?: "",
                    grid?.height?.let { "%.4f".format(Locale.US, it) } ?: "",
                    "%.9f".format(Locale.US, p.latitude),
                    "%.9f".format(Locale.US, p.longitude),
                    "%.4f".format(Locale.US, p.ellipsoidalHeight),
                    p.fixQuality.toString(),
                    p.hdop.toString(),
                    p.satellites.toString(),
                    p.timestampUtc.toString()
                )
                writer.write(cells.joinToString(",") { csvEscape(it) })
                writer.newLine()
            }
        }
        return file
    }

    private fun csvEscape(value: String): String =
        if (value.contains(",") || value.contains("\"")) "\"${value.replace("\"", "\"\"")}\"" else value
}
