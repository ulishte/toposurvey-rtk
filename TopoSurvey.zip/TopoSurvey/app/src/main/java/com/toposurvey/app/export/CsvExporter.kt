package com.toposurvey.app.export

import android.content.Context
import com.toposurvey.app.data.SurveyPointEntity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CsvExporter {

    /** Writes points to <app-external-files>/Export/<projectName>_<timestamp>.csv and returns the file. */
    fun export(context: Context, projectName: String, points: List<SurveyPointEntity>): File {
        val dir = File(context.getExternalFilesDir(null), "Export").apply { mkdirs() }
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val safeName = projectName.replace(Regex("[^A-Za-z0-9_-]"), "_")
        val file = File(dir, "${safeName}_$stamp.csv")

        file.bufferedWriter().use { writer ->
            writer.write("Code,Description,Latitude,Longitude,EllipsoidalHeight,FixQuality,HDOP,Satellites,TimestampUtc")
            writer.newLine()
            points.forEach { p ->
                writer.write(
                    listOf(
                        p.code,
                        p.description,
                        p.latitude,
                        p.longitude,
                        p.ellipsoidalHeight,
                        p.fixQuality,
                        p.hdop,
                        p.satellites,
                        p.timestampUtc
                    ).joinToString(",") { csvEscape(it.toString()) }
                )
                writer.newLine()
            }
        }
        return file
    }

    private fun csvEscape(value: String): String =
        if (value.contains(",") || value.contains("\"")) "\"${value.replace("\"", "\"\"")}\"" else value
}
