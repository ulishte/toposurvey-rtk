package com.toposurvey.app

import android.content.Context
import com.toposurvey.app.bluetooth.BluetoothLinkManager
import com.toposurvey.app.geo.CoordinateSystem
import com.toposurvey.app.geo.GridResult
import com.toposurvey.app.gnss.GnssFix
import com.toposurvey.app.gnss.NmeaParser
import com.toposurvey.app.gnss.NtripClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * App-scoped singleton that wires the Bluetooth link (rover) to the NMEA
 * parser and the NTRIP client (RTK corrections), and exposes the latest
 * decoded position - both as raw WGS84 and projected into the active
 * project's coordinate system.
 */
object SurveyEngine {
    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    lateinit var bluetooth: BluetoothLinkManager
        private set
    lateinit var ntrip: NtripClient
        private set

    private val _currentFix = MutableStateFlow<GnssFix?>(null)
    val currentFix: StateFlow<GnssFix?> = _currentFix

    private val _coordinateSystem = MutableStateFlow(CoordinateSystem.KRGJSH_2010)
    val coordinateSystem: StateFlow<CoordinateSystem> = _coordinateSystem

    /** Live grid position, recomputed whenever the fix or the system changes. */
    private val _currentGrid = MutableStateFlow<GridResult?>(null)
    val currentGrid: StateFlow<GridResult?> = _currentGrid

    var activeProjectId: Long? = null

    private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        initialized = true

        bluetooth = BluetoothLinkManager(engineScope)
        ntrip = NtripClient(engineScope)

        engineScope.launch {
            bluetooth.nmeaLines.collect { line ->
                val fix = NmeaParser.parseGga(line)
                if (fix != null) {
                    _currentFix.value = fix
                    ntrip.latestGga = fix.rawGga
                    _currentGrid.value = project(fix)
                }
            }
        }
    }

    fun setCoordinateSystemByName(name: String) {
        val cs = resolve(name)
        _coordinateSystem.value = cs
        _currentFix.value?.let { _currentGrid.value = project(it) }
    }

    fun resolve(name: String): CoordinateSystem =
        CoordinateSystem.PRESETS.firstOrNull { it.name == name } ?: CoordinateSystem.KRGJSH_2010

    fun project(fix: GnssFix, system: CoordinateSystem = _coordinateSystem.value): GridResult? =
        system.fromWgs84(fix.latitude, fix.longitude, fix.ellipsoidalHeight)

    fun project(
        latitude: Double,
        longitude: Double,
        height: Double,
        system: CoordinateSystem = _coordinateSystem.value
    ): GridResult? = system.fromWgs84(latitude, longitude, height)

    fun startCorrections(settings: com.toposurvey.app.gnss.NtripSettings) {
        ntrip.connect(settings) { rtcmBytes -> bluetooth.sendCorrectionBytes(rtcmBytes) }
    }
}
