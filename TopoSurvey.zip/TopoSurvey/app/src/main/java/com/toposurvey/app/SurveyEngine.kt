package com.toposurvey.app

import android.content.Context
import com.toposurvey.app.bluetooth.BluetoothLinkManager
import com.toposurvey.app.geo.CoordinateSystem
import com.toposurvey.app.geo.GridResult
import com.toposurvey.app.geo.Localization
import com.toposurvey.app.gnss.GnssFix
import com.toposurvey.app.gnss.NmeaParser
import com.toposurvey.app.gnss.NtripClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * App-scoped singleton wiring the rover link to the NMEA parser, the NTRIP
 * client and the active coordinate system.
 *
 * Heights: the rover reports the phase centre of the antenna. Everything the
 * surveyor sees and stores is the GROUND MARK, i.e. antenna height already
 * subtracted - getting this wrong is the classic source of a constant height
 * bias across a whole job.
 */
object SurveyEngine {
    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    lateinit var bluetooth: BluetoothLinkManager
        private set
    lateinit var ntrip: NtripClient
        private set

    /** Every decoded epoch, for averaging. */
    private val _fixes = MutableSharedFlow<GnssFix>(extraBufferCapacity = 64)
    val fixes: SharedFlow<GnssFix> = _fixes

    private val _currentFix = MutableStateFlow<GnssFix?>(null)
    val currentFix: StateFlow<GnssFix?> = _currentFix

    private val _baseSystem = MutableStateFlow(CoordinateSystem.KRGJSH_2010)
    private val _localization = MutableStateFlow(Localization())

    private val _coordinateSystem = MutableStateFlow(CoordinateSystem.KRGJSH_2010)
    val coordinateSystem: StateFlow<CoordinateSystem> = _coordinateSystem

    /** Pole / antenna height in metres, subtracted from every reported height. */
    private val _antennaHeight = MutableStateFlow(0.0)
    val antennaHeight: StateFlow<Double> = _antennaHeight

    private val _currentGrid = MutableStateFlow<GridResult?>(null)
    val currentGrid: StateFlow<GridResult?> = _currentGrid

    var activeProjectId: Long? = null

    private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        initialized = true

        bluetooth = BluetoothLinkManager(engineScope)
        ntrip = NtripClient(engineScope)

        engineScope.launch {
            bluetooth.nmeaLines.collect { line ->
                val fix = NmeaParser.parseGga(line)
                if (fix != null) {
                    _currentFix.value = fix
                    _fixes.tryEmit(fix)
                    ntrip.latestGga = fix.rawGga
                    _currentGrid.value = project(fix)
                }
            }
        }
    }

    // ---------- configuration ----------

    fun setAntennaHeight(metres: Double) {
        _antennaHeight.value = metres
        _currentFix.value?.let { _currentGrid.value = project(it) }
    }

    fun setCoordinateSystemByName(name: String) {
        _baseSystem.value = resolve(name)
        rebuildSystem()
    }

    fun setLocalization(localization: Localization) {
        _localization.value = localization
        rebuildSystem()
    }

    fun clearLocalization() = setLocalization(Localization())

    val localization: Localization get() = _localization.value

    private fun rebuildSystem() {
        _coordinateSystem.value = _baseSystem.value.copy(localization = _localization.value)
        _currentFix.value?.let { _currentGrid.value = project(it) }
    }

    fun resolve(name: String): CoordinateSystem =
        CoordinateSystem.PRESETS.firstOrNull { it.name == name } ?: CoordinateSystem.KRGJSH_2010

    // ---------- projection ----------

    /** Ground-mark ellipsoidal height for a raw epoch. */
    fun groundHeight(fix: GnssFix): Double = fix.ellipsoidalHeight - _antennaHeight.value

    fun project(fix: GnssFix, system: CoordinateSystem = _coordinateSystem.value): GridResult? =
        system.fromWgs84(fix.latitude, fix.longitude, groundHeight(fix))

    fun project(
        latitude: Double,
        longitude: Double,
        height: Double,
        system: CoordinateSystem = _coordinateSystem.value
    ): GridResult? = system.fromWgs84(latitude, longitude, height)

    /** Project without any site calibration - what calibration itself must use. */
    fun projectUncalibrated(latitude: Double, longitude: Double, height: Double): GridResult? =
        _baseSystem.value.fromWgs84(latitude, longitude, height)

    fun startCorrections(settings: com.toposurvey.app.gnss.NtripSettings) {
        ntrip.connect(settings) { rtcmBytes -> bluetooth.sendCorrectionBytes(rtcmBytes) }
    }
}
