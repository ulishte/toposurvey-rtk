package com.toposurvey.app

import android.content.Context
import com.toposurvey.app.bluetooth.BluetoothLinkManager
import com.toposurvey.app.gnss.GnssFix
import com.toposurvey.app.gnss.NmeaParser
import com.toposurvey.app.gnss.NtripClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

/**
 * App-scoped singleton that wires the Bluetooth link (rover) to the NMEA
 * parser and the NTRIP client (RTK corrections), and exposes the latest
 * decoded position as a StateFlow every screen can observe.
 *
 * Data flow:
 *   rover --(NMEA over Bluetooth SPP)--> BluetoothLinkManager --> NmeaParser --> currentFix
 *   NTRIP caster --(RTCM)--> NtripClient --(bytes)--> BluetoothLinkManager --> rover
 */
object SurveyEngine {
    private val engineScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    lateinit var bluetooth: BluetoothLinkManager
        private set
    lateinit var ntrip: NtripClient
        private set

    private val _currentFix = MutableStateFlow<GnssFix?>(null)
    val currentFix: StateFlow<GnssFix?> = _currentFix

    /** Which project is currently active in the survey/library/stakeout screens. */
    var activeProjectId: Long? = null

    private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        initialized = true

        bluetooth = BluetoothLinkManager(engineScope)
        ntrip = NtripClient(engineScope)

        engineScope.launch {
            bluetooth.nmeaLines.collect { line ->
                val fix = NmeaParser.parseGga(line)
                if (fix != null) {
                    _currentFix.value = fix
                    ntrip.latestGga = fix.rawGga
                }
            }
        }
    }

    /** Wire NTRIP RTCM output straight to the rover's Bluetooth socket. */
    fun startCorrections(settings: com.toposurvey.app.gnss.NtripSettings) {
        ntrip.connect(settings) { rtcmBytes -> bluetooth.sendCorrectionBytes(rtcmBytes) }
    }
}
