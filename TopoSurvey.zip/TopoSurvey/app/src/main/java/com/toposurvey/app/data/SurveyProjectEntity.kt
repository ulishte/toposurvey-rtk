package com.toposurvey.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class SurveyProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    /** Placeholder for phase 2: local grid / projection assigned to this project. */
    val coordinateSystemName: String = "WGS84 (Lat/Lon)"
)
