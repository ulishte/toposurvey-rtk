package com.toposurvey.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class SurveyProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val createdAt: Long = System.currentTimeMillis(),
    /**
     * Name of the coordinate system preset used to project this project's
     * points. Resolved against CoordinateSystem.PRESETS at runtime, so changing
     * it re-projects every stored point without touching the raw GNSS data.
     */
    val coordinateSystemName: String = "KRGJSH-2010 (Shqipëri)"
)
