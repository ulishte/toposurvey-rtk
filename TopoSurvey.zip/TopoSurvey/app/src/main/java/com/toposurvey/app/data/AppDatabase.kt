package com.toposurvey.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

@Database(
    entities = [
        SurveyProjectEntity::class,
        SurveyPointEntity::class,
        ControlPointEntity::class,
        LocalizationEntity::class
    ],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun pointDao(): PointDao
    abstract fun controlPointDao(): ControlPointDao
    abstract fun localizationDao(): LocalizationDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        /** Adds the geoid separation so orthometric heights survive an update. */
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE points ADD COLUMN geoidSeparation REAL NOT NULL DEFAULT 0")
            }
        }

        fun getInstance(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "toposurvey.db"
                )
                    .addMigrations(MIGRATION_2_3)
                    // Only used for the pre-calibration test schema (v1).
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { instance = it }
            }
    }
}
