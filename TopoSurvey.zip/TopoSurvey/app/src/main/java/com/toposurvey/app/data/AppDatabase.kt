package com.toposurvey.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        SurveyProjectEntity::class,
        SurveyPointEntity::class,
        ControlPointEntity::class,
        LocalizationEntity::class
    ],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun projectDao(): ProjectDao
    abstract fun pointDao(): PointDao
    abstract fun controlPointDao(): ControlPointDao
    abstract fun localizationDao(): LocalizationDao

    companion object {
        @Volatile private var instance: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "toposurvey.db"
                )
                    // Version 1 was the pre-calibration schema shipped for testing only.
                    // Recreating is acceptable here and avoids any migration risk.
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { instance = it }
            }
    }
}
