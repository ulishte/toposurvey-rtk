package com.toposurvey.app.data

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "points",
    foreignKeys = [
        ForeignKey(
            entity = SurveyProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("projectId")]
)
data class SurveyPointEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val code: String,
    val description: String,
    val latitude: Double,
    val longitude: Double,
    /**
     * Ellipsoidal height of the GROUND MARK - the antenna height has already
     * been subtracted, so this is the value the surveyor actually wants.
     */
    val ellipsoidalHeight: Double,
    /** Pole/antenna height that was subtracted, kept for traceability. */
    val antennaHeight: Double = 0.0,
    /**
     * Geoid separation N at this point, so the orthometric (sea-level) height
     * can be recovered exactly: orthometric = ellipsoidal - N.
     */
    @ColumnInfo(defaultValue = "0")
    val geoidSeparation: Double = 0.0,
    val fixQuality: Int,
    val hdop: Double,
    val satellites: Int,
    /** How many GNSS epochs were averaged into this point. */
    val epochsAveraged: Int = 1,
    val timestampUtc: Long
) {
    /** Height above mean sea level - what most Albanian deliverables ask for. */
    val orthometricHeight: Double get() = ellipsoidalHeight - geoidSeparation
}
