package com.toposurvey.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "points",
    foreignKeys = [
        ForeignKey(
            entity = SurveyProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("projectId")]
)
data class SurveyPointEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val code: String,
    val description: String,
    val latitude: Double,
    val longitude: Double,
    /** Ellipsoidal height in meters (GGA altitude + geoid separation). */
    val ellipsoidalHeight: Double,
    /** NMEA GGA fix quality: 0 invalid, 1 GPS, 2 DGPS, 4 RTK fixed, 5 RTK float, ... */
    val fixQuality: Int,
    val hdop: Double,
    val satellites: Int,
    val timestampUtc: Long
)
