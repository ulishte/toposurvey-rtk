package com.toposurvey.app.data

import kotlinx.coroutines.flow.Flow

/**
 * Thin wrapper around the DAOs so ViewModels never touch Room directly.
 */
class SurveyRepository(
    private val projectDao: ProjectDao,
    private val pointDao: PointDao
) {
    fun observeProjects(): Flow<List<SurveyProjectEntity>> = projectDao.observeAll()

    suspend fun createProject(name: String, coordinateSystemName: String): Long =
        projectDao.insert(SurveyProjectEntity(name = name, coordinateSystemName = coordinateSystemName))

    suspend fun deleteProject(project: SurveyProjectEntity) = projectDao.delete(project)

    suspend fun getProject(id: Long): SurveyProjectEntity? = projectDao.getById(id)

    suspend fun setCoordinateSystem(projectId: Long, name: String) =
        projectDao.updateCoordinateSystem(projectId, name)

    fun observePoints(projectId: Long): Flow<List<SurveyPointEntity>> = pointDao.observeForProject(projectId)

    suspend fun addPoint(point: SurveyPointEntity): Long = pointDao.insert(point)

    suspend fun deletePoint(point: SurveyPointEntity) = pointDao.delete(point)

    suspend fun getPointsOnce(projectId: Long): List<SurveyPointEntity> = pointDao.getForProjectOnce(projectId)
}
