package com.toposurvey.app.data

import kotlinx.coroutines.flow.Flow

/**
 * Thin wrapper around the DAOs so ViewModels never touch Room directly.
 * Makes it straightforward to add caching, sync, or a remote backend later
 * without changing call sites.
 */
class SurveyRepository(
    private val projectDao: ProjectDao,
    private val pointDao: PointDao
) {
    fun observeProjects(): Flow<List<SurveyProjectEntity>> = projectDao.observeAll()

    suspend fun createProject(name: String): Long = projectDao.insert(SurveyProjectEntity(name = name))

    suspend fun deleteProject(project: SurveyProjectEntity) = projectDao.delete(project)

    suspend fun getProject(id: Long): SurveyProjectEntity? = projectDao.getById(id)

    fun observePoints(projectId: Long): Flow<List<SurveyPointEntity>> = pointDao.observeForProject(projectId)

    suspend fun addPoint(point: SurveyPointEntity): Long = pointDao.insert(point)

    suspend fun deletePoint(point: SurveyPointEntity) = pointDao.delete(point)

    suspend fun getPointsOnce(projectId: Long): List<SurveyPointEntity> = pointDao.getForProjectOnce(projectId)
}
