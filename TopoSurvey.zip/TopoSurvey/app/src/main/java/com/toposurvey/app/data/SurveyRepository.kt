package com.toposurvey.app.data

import kotlinx.coroutines.flow.Flow

/** Thin wrapper around the DAOs so ViewModels never touch Room directly. */
class SurveyRepository(
    private val projectDao: ProjectDao,
    private val pointDao: PointDao,
    private val controlPointDao: ControlPointDao,
    private val localizationDao: LocalizationDao
) {
    // ---- projects ----
    fun observeProjects(): Flow<List<SurveyProjectEntity>> = projectDao.observeAll()

    suspend fun createProject(name: String, coordinateSystemName: String): Long =
        projectDao.insert(SurveyProjectEntity(name = name, coordinateSystemName = coordinateSystemName))

    suspend fun deleteProject(project: SurveyProjectEntity) = projectDao.delete(project)

    suspend fun getProject(id: Long): SurveyProjectEntity? = projectDao.getById(id)

    suspend fun setCoordinateSystem(projectId: Long, name: String) =
        projectDao.updateCoordinateSystem(projectId, name)

    // ---- survey points ----
    fun observePoints(projectId: Long): Flow<List<SurveyPointEntity>> = pointDao.observeForProject(projectId)

    suspend fun addPoint(point: SurveyPointEntity): Long = pointDao.insert(point)

    suspend fun deletePoint(point: SurveyPointEntity) = pointDao.delete(point)

    suspend fun getPointsOnce(projectId: Long): List<SurveyPointEntity> = pointDao.getForProjectOnce(projectId)

    // ---- calibration ----
    fun observeControlPoints(projectId: Long): Flow<List<ControlPointEntity>> =
        controlPointDao.observeForProject(projectId)

    suspend fun getControlPoints(projectId: Long): List<ControlPointEntity> =
        controlPointDao.getForProject(projectId)

    suspend fun addControlPoint(point: ControlPointEntity): Long = controlPointDao.insert(point)

    suspend fun updateControlPoint(point: ControlPointEntity) = controlPointDao.update(point)

    suspend fun deleteControlPoint(point: ControlPointEntity) = controlPointDao.delete(point)

    suspend fun getLocalization(projectId: Long): LocalizationEntity? = localizationDao.get(projectId)

    suspend fun saveLocalization(entity: LocalizationEntity) = localizationDao.upsert(entity)

    suspend fun clearLocalization(projectId: Long) = localizationDao.clear(projectId)
}
