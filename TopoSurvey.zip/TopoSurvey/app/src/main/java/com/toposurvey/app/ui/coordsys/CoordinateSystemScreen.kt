package com.toposurvey.app.ui.coordsys

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController

/**
 * Choose the coordinate system the active project reports in. Raw WGS84 is
 * always what gets stored, so switching systems re-projects existing points
 * rather than losing accuracy.
 */
@Composable
fun CoordinateSystemScreen(
    navController: NavHostController,
    viewModel: CoordinateSystemViewModel = viewModel()
) {
    val active by viewModel.active.collectAsState()

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Sistemi i Koordinatave", style = MaterialTheme.typography.headlineSmall)
        Text("Aktiv: ${active.name}", style = MaterialTheme.typography.bodyMedium)

        viewModel.presets.forEach { cs ->
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(cs.name, style = MaterialTheme.typography.titleSmall)
                    Text(viewModel.describe(cs), style = MaterialTheme.typography.bodySmall)
                    if (cs.name == active.name) {
                        Text("✓ I zgjedhur", style = MaterialTheme.typography.labelMedium)
                    } else {
                        Button(onClick = { viewModel.select(cs) }) { Text("Zgjidh") }
                    }
                }
            }
        }

        Text(
            "Shënim: pikat ruhen gjithmonë si WGS84 nga rover-i. Ndryshimi i sistemit " +
                "riprojekton automatikisht të gjitha pikat ekzistuese.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}
