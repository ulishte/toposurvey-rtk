package com.toposurvey.app.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ControlPointDao {
    @Query("SELECT * FROM control_points WHERE projectId = :projectId ORDER BY id")
    fun observeForProject(projectId: Long): Flow<List<ControlPointEntity>>

    @Query("SELECT * FROM control_points WHERE projectId = :projectId ORDER BY id")
    suspend fun getForProject(projectId: Long): List<ControlPointEntity>

    @Insert
    suspend fun insert(point: ControlPointEntity): Long

    @Update
    suspend fun update(point: ControlPointEntity)

    @Delete
    suspend fun delete(point: ControlPointEntity)

    @Query("DELETE FROM control_points WHERE projectId = :projectId")
    suspend fun clearForProject(projectId: Long)
}
