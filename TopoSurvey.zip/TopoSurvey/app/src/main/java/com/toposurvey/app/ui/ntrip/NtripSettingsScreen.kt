package com.toposurvey.app.ui.ntrip

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavHostController
import com.toposurvey.app.gnss.NtripState

/**
 * Standard NTRIP client settings - works with any NTRIP caster (a CORS
 * network, or one operated by the receiver vendor), which is the
 * industry-standard, license-free way to deliver RTK corrections.
 */
@Composable
fun NtripSettingsScreen(navController: NavHostController, viewModel: NtripSettingsViewModel = viewModel()) {
    val state by viewModel.state.collectAsState()
    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("2101") }
    var mountpoint by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Korrigjime RTK (NTRIP)", style = MaterialTheme.typography.headlineSmall)
        Text(
            when (val s = state) {
                is NtripState.Disconnected -> "I shkëputur"
                is NtripState.Connecting -> "Duke u lidhur..."
                is NtripState.Streaming -> "Duke marrë korrigjime"
                is NtripState.Error -> "Gabim: ${s.message}"
            }
        )

        OutlinedTextField(value = host, onValueChange = { host = it }, label = { Text("Host i caster-it (p.sh. rtk.example.com)") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = port, onValueChange = { port = it }, label = { Text("Porta") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = mountpoint, onValueChange = { mountpoint = it }, label = { Text("Mountpoint") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = user, onValueChange = { user = it }, label = { Text("Përdoruesi") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = pass, onValueChange = { pass = it }, label = { Text("Fjalëkalimi") }, modifier = Modifier.fillMaxWidth())

        Button(
            onClick = { viewModel.connect(host, port.toIntOrNull() ?: 2101, mountpoint, user, pass) },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Lidhu") }

        Button(onClick = { viewModel.disconnect() }, modifier = Modifier.fillMaxWidth()) {
            Text("Shkëput")
        }
    }
}
