package com.toposurvey.app.bluetooth

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.Context
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.IOException
import java.util.UUID

sealed class BtLinkState {
    data object Disconnected : BtLinkState()
    data object Connecting : BtLinkState()
    data class Connected(val deviceName: String) : BtLinkState()
    data class Error(val message: String) : BtLinkState()
}

/**
 * Manages the classic-Bluetooth (SPP) link to the GNSS rover: connects,
 * exposes each raw NMEA line as it arrives, and lets callers push RTCM
 * correction bytes (from the NTRIP client) straight back down the same
 * socket - this is exactly how the rover expects to receive corrections
 * when the phone is acting as the data-link between caster and receiver.
 */
class BluetoothLinkManager(private val scope: CoroutineScope) {

    companion object {
        // Standard Serial Port Profile UUID used by essentially all GNSS/RTK receivers.
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    private val _state = MutableStateFlow<BtLinkState>(BtLinkState.Disconnected)
    val state: StateFlow<BtLinkState> = _state

    private val _nmeaLines = MutableSharedFlow<String>(extraBufferSize = 64)
    val nmeaLines: SharedFlow<String> = _nmeaLines

    private var socket: BluetoothSocket? = null
    private var readJob: Job? = null

    fun pairedDevices(context: Context): List<BluetoothDevice> {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return emptyList()
        return runCatching { adapter.bondedDevices.toList() }.getOrDefault(emptyList())
    }

    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice) {
        disconnect()
        readJob = scope.launch(Dispatchers.IO) {
            try {
                _state.value = BtLinkState.Connecting
                val adapter = BluetoothAdapter.getDefaultAdapter()
                runCatching { adapter?.cancelDiscovery() }

                val sock = device.createRfcommSocketToServiceRecord(SPP_UUID)
                socket = sock
                sock.connect()

                _state.value = BtLinkState.Connected(device.name ?: device.address)

                val reader = sock.inputStream.bufferedReader()
                while (isActive) {
                    val line = reader.readLine() ?: break
                    if (line.isNotBlank()) _nmeaLines.emit(line)
                }
                _state.value = BtLinkState.Disconnected
            } catch (io: IOException) {
                _state.value = BtLinkState.Error(io.message ?: "Lidhja Bluetooth dështoi")
            } finally {
                runCatching { socket?.close() }
            }
        }
    }

    /** Forward RTCM correction bytes from the NTRIP caster down to the rover. */
    fun sendCorrectionBytes(bytes: ByteArray) {
        val sock = socket ?: return
        runCatching { sock.outputStream.write(bytes) }
    }

    fun disconnect() {
        readJob?.cancel()
        readJob = null
        runCatching { socket?.close() }
        socket = null
        _state.value = BtLinkState.Disconnected
    }
}
