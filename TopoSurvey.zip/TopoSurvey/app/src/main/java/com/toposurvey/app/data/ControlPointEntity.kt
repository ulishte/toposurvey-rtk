package com.toposurvey.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/**
 * One pair used by the site calibration: what the rover measured on the mark
 * (projected grid coordinates) versus the coordinates the mark is known to
 * have in the client's local system.
 */
@Entity(
    tableName = "control_points",
    foreignKeys = [
        ForeignKey(
            entity = SurveyProjectEntity::class,
            parentColumns = ["id"],
            childColumns = ["projectId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("projectId")]
)
data class ControlPointEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val label: String,
    val measuredEasting: Double,
    val measuredNorthing: Double,
    val measuredHeight: Double,
    val knownEasting: Double,
    val knownNorthing: Double,
    val knownHeight: Double,
    val enabled: Boolean = true
)
