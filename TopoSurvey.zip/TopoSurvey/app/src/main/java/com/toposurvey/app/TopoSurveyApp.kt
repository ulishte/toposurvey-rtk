package com.toposurvey.app

import android.app.Application
import com.toposurvey.app.data.AppDatabase
import com.toposurvey.app.data.SurveyRepository

/**
 * Application-wide singleton wiring: database, repository, Bluetooth link to the
 * rover and the NTRIP client used to stream RTK corrections back to it.
 *
 * Kept deliberately simple (no DI framework) for a phase-1 skeleton. If the
 * project grows, swap this for Hilt/Koin without touching the ViewModels much,
 * since they only depend on SurveyEngine's public members.
 */
class TopoSurveyApp : Application() {

    lateinit var repository: SurveyRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val db = AppDatabase.getInstance(this)
        repository = SurveyRepository(db.projectDao(), db.pointDao())
        SurveyEngine.init(this)
    }
}
