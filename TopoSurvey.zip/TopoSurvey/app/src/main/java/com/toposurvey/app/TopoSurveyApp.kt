package com.toposurvey.app

import android.app.Application
import com.toposurvey.app.data.AppDatabase
import com.toposurvey.app.data.SurveyRepository

class TopoSurveyApp : Application() {

    lateinit var repository: SurveyRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val db = AppDatabase.getInstance(this)
        repository = SurveyRepository(
            db.projectDao(),
            db.pointDao(),
            db.controlPointDao(),
            db.localizationDao()
        )
        SurveyEngine.init(this)
    }
}
