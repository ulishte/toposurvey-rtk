package com.toposurvey.app.geo

/**
 * A full coordinate system definition: which ellipsoid, how to get from the
 * GNSS (WGS84) datum onto it, how to project it to a plane, and any site
 * localization fitted on top.
 *
 * The pipeline for every measured point is:
 *   WGS84 lat/lon/h  ->  ECEF  ->  [Helmert]  ->  target-datum lat/lon/h
 *                    ->  [Transverse Mercator]  ->  grid E/N
 *                    ->  [Localization]  ->  local E/N and adjusted height
 */
data class CoordinateSystem(
    val name: String,
    val ellipsoid: Ellipsoid,
    val projection: TmParameters?,
    val datumTransform: DatumTransform = DatumTransform(),
    val localization: Localization = Localization()
) {

    /** True when points should simply be reported as WGS84 lat/lon. */
    val isGeographicOnly: Boolean get() = projection == null

    /**
     * Convert a WGS84 GNSS position into this system's grid coordinates.
     * Returns null for a geographic-only system (nothing to project).
     */
    fun fromWgs84(latitude: Double, longitude: Double, ellipsoidalHeight: Double): GridResult? {
        val proj = projection ?: return null

        var lat = latitude
        var lon = longitude
        var h = ellipsoidalHeight

        if (!datumTransform.isIdentity) {
            val ecefWgs = Geodesy.geodeticToEcef(Ellipsoid.WGS84, lat, lon, h)
            val ecefTarget = datumTransform.apply(ecefWgs)
            val (la, lo, hh) = Geodesy.ecefToGeodetic(ellipsoid, ecefTarget)
            lat = la; lon = lo; h = hh
        }

        val gridRaw = TransverseMercator.forward(ellipsoid, proj, LatLon(lat, lon))
        val grid = localization.apply(gridRaw)
        val height = localization.applyHeight(h)

        return GridResult(
            easting = grid.easting,
            northing = grid.northing,
            height = height,
            convergenceDegrees = TransverseMercator.convergence(ellipsoid, proj, LatLon(lat, lon)),
            scaleFactor = TransverseMercator.pointScaleFactor(ellipsoid, proj, LatLon(lat, lon))
        )
    }

    /**
     * Inverse of [fromWgs84] - used when the surveyor types a design coordinate
     * to stake out and the app needs the WGS84 target to navigate to.
     */
    fun toWgs84(easting: Double, northing: Double, height: Double): Triple<Double, Double, Double>? {
        val proj = projection ?: return null

        val gridRaw = localization.invert(GridXY(easting, northing))
        val h0 = height - localization.verticalShift
        val ll = TransverseMercator.inverse(ellipsoid, proj, gridRaw)

        if (datumTransform.isIdentity) return Triple(ll.latitude, ll.longitude, h0)

        val ecefTarget = Geodesy.geodeticToEcef(ellipsoid, ll.latitude, ll.longitude, h0)
        val ecefWgs = datumTransform.inverse().apply(ecefTarget)
        val (la, lo, hh) = Geodesy.ecefToGeodetic(Ellipsoid.WGS84, ecefWgs)
        return Triple(la, lo, hh)
    }

    companion object {
        val WGS84_GEOGRAPHIC = CoordinateSystem(
            name = "WGS 84 (gjeografike lat/lon)",
            ellipsoid = Ellipsoid.WGS84,
            projection = null
        )

        /**
         * Albania's official national system: Transverse Mercator on GRS80/ETRS89,
         * central meridian 20°E, scale 0.9999, false easting 500 000 m.
         * ETRS89 and WGS84 agree to a few centimetres, so no datum shift is applied.
         */
        val KRGJSH_2010 = CoordinateSystem(
            name = "KRGJSH-2010 (Shqipëri)",
            ellipsoid = Ellipsoid.GRS80,
            projection = TmParameters(
                latitudeOfOrigin = 0.0,
                centralMeridian = 20.0,
                scaleFactor = 0.9999,
                falseEasting = 500000.0,
                falseNorthing = 0.0
            )
        )

        /** Standard UTM zone on WGS84. [zone] is 1..60; [north] false northing handling. */
        fun utm(zone: Int, north: Boolean = true): CoordinateSystem = CoordinateSystem(
            name = "UTM zona $zone${if (north) "N" else "S"} (WGS 84)",
            ellipsoid = Ellipsoid.WGS84,
            projection = TmParameters(
                latitudeOfOrigin = 0.0,
                centralMeridian = -183.0 + 6.0 * zone,
                scaleFactor = 0.9996,
                falseEasting = 500000.0,
                falseNorthing = if (north) 0.0 else 10000000.0
            )
        )

        /** UTM zone number that contains a given longitude. */
        fun utmZoneFor(longitude: Double): Int {
            val z = Math.floor((longitude + 180.0) / 6.0).toInt() + 1
            return z.coerceIn(1, 60)
        }

        /** Ready-made choices offered in the UI. Albania is listed first. */
        val PRESETS: List<CoordinateSystem> = listOf(
            KRGJSH_2010,
            utm(34, true),
            utm(33, true),
            WGS84_GEOGRAPHIC
        )
    }
}

/** Result of projecting a GNSS position into a grid. */
data class GridResult(
    val easting: Double,
    val northing: Double,
    val height: Double,
    /** Grid convergence in degrees (grid north vs true north). */
    val convergenceDegrees: Double,
    /** Point scale factor - multiply ground distance by this to get grid distance. */
    val scaleFactor: Double
)
